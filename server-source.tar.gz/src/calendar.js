/**
 * In-house appointment calendar (one shared calendar, Miami time).
 *
 * Settings live in settings/calendar, appointments in the appointments collection.
 * Slots are computed from working hours, appointment length, travel time between
 * appointments and how many appointments can overlap.
 */

const TZ = 'America/New_York';
const DAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];

export const APPOINTMENT_STATUSES = ['scheduled', 'completed', 'canceled', 'no_show'];

export class CalendarError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

const DEFAULTS = {
  hours: {
    sun: null,
    mon: { start: '09:00', end: '18:00' },
    tue: { start: '09:00', end: '18:00' },
    wed: { start: '09:00', end: '18:00' },
    thu: { start: '09:00', end: '18:00' },
    fri: { start: '09:00', end: '17:00' },
    sat: { start: '10:00', end: '14:00' },
  },
  appointmentMinutes: 90,
  travelMinutes: 30,
  slotStepMinutes: 30,
  concurrent: 1,
  leadTimeHours: 4,
  horizonDays: 14,
  blackoutDates: [], // ['2026-12-25']
};

/* ── Miami-time helpers (no external date library) ───────── */

const partsOf = (date) => {
  const f = new Intl.DateTimeFormat('en-US', {
    timeZone: TZ,
    weekday: 'short',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(date);
  const get = (t) => f.find((p) => p.type === t)?.value || '';
  return {
    weekday: get('weekday').toLowerCase().slice(0, 3),
    date: `${get('year')}-${get('month')}-${get('day')}`,
    hour: Number(get('hour')) % 24,
    minute: Number(get('minute')),
  };
};

/** Offset of the Miami time zone at a moment, in minutes (e.g. -240 in summer). */
function tzOffsetMinutes(date) {
  const p = partsOf(date);
  const asUtc = Date.UTC(Number(p.date.slice(0, 4)), Number(p.date.slice(5, 7)) - 1, Number(p.date.slice(8, 10)), p.hour, p.minute);
  return Math.round((asUtc - Math.floor(date.getTime() / 60000) * 60000) / 60000);
}

/** "2026-09-18" + "14:30" in Miami → Date */
export function miamiToDate(dateStr, timeStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const [hh, mm] = timeStr.split(':').map(Number);
  const guess = new Date(Date.UTC(y, m - 1, d, hh, mm));
  const offset = tzOffsetMinutes(guess);
  const exact = new Date(guess.getTime() - offset * 60000);
  // One correction pass for days where the offset changes (DST)
  const offset2 = tzOffsetMinutes(exact);
  return offset2 === offset ? exact : new Date(guess.getTime() - offset2 * 60000);
}

export const miamiDateKey = (date) => partsOf(date).date;
export const miamiWeekday = (date) => partsOf(date).weekday;

export const formatSlot = (date) =>
  new Intl.DateTimeFormat('en-US', { timeZone: TZ, weekday: 'long', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date);

const addDays = (date, days) => new Date(date.getTime() + days * 86400000);
const clean = (v, max) => String(v ?? '').trim().slice(0, max);
const isTime = (v) => /^([01]\d|2[0-3]):[0-5]\d$/.test(v);

/* ── Service ─────────────────────────────────────────────── */

export function createCalendar({ store, realtime, logger = console }) {
  let cache = null;

  async function settings() {
    if (!cache) {
      const raw = await store.getSettings('calendar');
      cache = { ...DEFAULTS, ...raw, hours: { ...DEFAULTS.hours, ...(raw.hours || {}) }, blackoutDates: raw.blackoutDates || [] };
    }
    return cache;
  }

  async function updateSettings(body, agent) {
    const s = await settings();
    const patch = {};
    if (body.hours && typeof body.hours === 'object') {
      const hours = {};
      for (const key of DAY_KEYS) {
        const day = body.hours[key];
        if (!day || !day.start || !day.end) {
          hours[key] = null;
          continue;
        }
        if (!isTime(day.start) || !isTime(day.end) || day.start >= day.end) throw new CalendarError(`Check the working hours for ${key}.`);
        hours[key] = { start: day.start, end: day.end };
      }
      patch.hours = hours;
    }
    const num = (key, min, max) => {
      if (!(key in body)) return;
      const n = Math.round(Number(body[key]));
      if (!Number.isFinite(n) || n < min || n > max) throw new CalendarError(`${key} must be between ${min} and ${max}.`);
      patch[key] = n;
    };
    num('appointmentMinutes', 15, 480);
    num('travelMinutes', 0, 240);
    num('slotStepMinutes', 15, 120);
    num('concurrent', 1, 10);
    num('leadTimeHours', 0, 168);
    num('horizonDays', 1, 60);
    if (Array.isArray(body.blackoutDates)) {
      patch.blackoutDates = body.blackoutDates.filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d)).slice(0, 200);
    }
    await store.setSettings('calendar', { ...patch, changedBy: agent });
    cache = null;
    return settings();
  }

  const busyList = async (from, to) =>
    (await store.listAppointments({ from: from.toISOString(), to: to.toISOString() })).filter((a) => a.status === 'scheduled');

  /** Free start times in the next `horizonDays`, Miami time. */
  async function openSlots({ limit = 40, from = new Date(), skipAppointmentId = '' } = {}) {
    const s = await settings();
    const earliest = new Date(Math.max(from.getTime(), Date.now() + s.leadTimeHours * 3600000));
    const until = addDays(new Date(), s.horizonDays);
    const busy = (await busyList(addDays(earliest, -1), addDays(until, 1))).filter((a) => a.id !== skipAppointmentId);
    const slots = [];

    for (let day = 0; day <= s.horizonDays && slots.length < limit; day++) {
      const date = addDays(earliest, day);
      const key = miamiDateKey(date);
      const hours = s.hours[miamiWeekday(date)];
      if (!hours || s.blackoutDates.includes(key)) continue;

      const dayStart = miamiToDate(key, hours.start);
      const dayEnd = miamiToDate(key, hours.end);
      for (let t = dayStart.getTime(); t + s.appointmentMinutes * 60000 <= dayEnd.getTime(); t += s.slotStepMinutes * 60000) {
        if (t < earliest.getTime()) continue;
        const start = new Date(t);
        const end = new Date(t + s.appointmentMinutes * 60000);
        const overlapping = busy.filter((a) => {
          const aStart = new Date(a.start).getTime() - s.travelMinutes * 60000;
          const aEnd = new Date(a.end).getTime() + s.travelMinutes * 60000;
          return t < aEnd && end.getTime() > aStart;
        }).length;
        if (overlapping < s.concurrent) slots.push({ start: start.toISOString(), end: end.toISOString(), label: formatSlot(start) });
        if (slots.length >= limit) break;
      }
    }
    return slots;
  }

  /** A short list the AI can read out on the call. */
  async function slotsForCall(count = 6) {
    const slots = await openSlots({ limit: 200 });
    const picked = [];
    const perDay = new Map();
    for (const slot of slots) {
      const day = miamiDateKey(new Date(slot.start));
      const used = perDay.get(day) || 0;
      if (used >= 2) continue; // spread the options across days
      perDay.set(day, used + 1);
      picked.push(slot);
      if (picked.length >= count) break;
    }
    return picked;
  }

  async function isFree(startIso, skipAppointmentId = '') {
    const s = await settings();
    const start = new Date(startIso);
    const slots = await openSlots({ limit: 500, from: new Date(Math.min(Date.now(), start.getTime())), skipAppointmentId });
    return slots.some((slot) => Math.abs(new Date(slot.start).getTime() - start.getTime()) < 60000) ? { ok: true, minutes: s.appointmentMinutes } : { ok: false };
  }

  async function book({ leadId, start, source = 'agent', agent = '', allOwnersConfirmed = false, notes = '', force = false }) {
    const s = await settings();
    const lead = await store.getLead(leadId);
    if (!lead) throw new CalendarError('Lead not found.', 404);
    const startDate = new Date(start);
    if (Number.isNaN(startDate.getTime())) throw new CalendarError('Invalid appointment time.');
    if (startDate.getTime() < Date.now()) throw new CalendarError('That time is in the past.');
    if (!force) {
      const free = await isFree(startDate.toISOString());
      if (!free.ok) throw new CalendarError('That time is no longer open. Pick another slot.', 409);
    }
    const end = new Date(startDate.getTime() + s.appointmentMinutes * 60000);
    const id = await store.createAppointment({
      leadId,
      leadName: [lead.firstName, lead.lastName].filter(Boolean).join(' '),
      phone: lead.phone || '',
      projectType: lead.projectType || '',
      county: lead.county || '',
      zipCode: lead.zipCode || '',
      start: startDate.toISOString(),
      end: end.toISOString(),
      status: 'scheduled',
      source,
      agent,
      allOwnersConfirmed: Boolean(allOwnersConfirmed),
      notes: clean(notes, 1000),
    });
    await store.updateLead(leadId, { nextAppointmentAt: startDate.toISOString(), appointmentStatus: 'scheduled' });
    const appointment = await store.getAppointment(id);
    realtime?.io.to('admins').emit('appointment:upsert', appointment);
    logger.log(`  📅 Appointment booked for ${appointment.leadName} — ${formatSlot(startDate)} (${source})`);
    return appointment;
  }

  async function update(id, patch, agent) {
    const current = await store.getAppointment(id);
    if (!current) throw new CalendarError('Appointment not found.', 404);
    const next = {};
    if (patch.status) {
      if (!APPOINTMENT_STATUSES.includes(patch.status)) throw new CalendarError('Unknown status.');
      next.status = patch.status;
    }
    if ('allOwnersConfirmed' in patch) next.allOwnersConfirmed = Boolean(patch.allOwnersConfirmed);
    if ('notes' in patch) next.notes = clean(patch.notes, 1000);
    if (patch.start) {
      const s = await settings();
      const startDate = new Date(patch.start);
      if (Number.isNaN(startDate.getTime())) throw new CalendarError('Invalid appointment time.');
      const free = await isFree(startDate.toISOString(), id);
      if (!free.ok) throw new CalendarError('That time is not open. Pick another slot.', 409);
      next.start = startDate.toISOString();
      next.end = new Date(startDate.getTime() + s.appointmentMinutes * 60000).toISOString();
    }
    next.updatedBy = agent;
    await store.updateAppointment(id, next);
    const appointment = await store.getAppointment(id);
    if (appointment.status === 'scheduled') {
      await store.updateLead(appointment.leadId, { nextAppointmentAt: appointment.start, appointmentStatus: 'scheduled' });
    } else {
      await store.updateLead(appointment.leadId, { appointmentStatus: appointment.status });
    }
    realtime?.io.to('admins').emit('appointment:upsert', appointment);
    return appointment;
  }

  async function list({ from, to } = {}) {
    const start = from ? new Date(from) : addDays(new Date(), -7);
    const end = to ? new Date(to) : addDays(new Date(), 30);
    return store.listAppointments({ from: start.toISOString(), to: end.toISOString() });
  }

  const forLead = (leadId) => store.listAppointmentsForLead(leadId);

  return { settings, updateSettings, openSlots, slotsForCall, isFree, book, update, list, forLead, formatSlot, DEFAULTS };
}
