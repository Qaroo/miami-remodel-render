import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { issueMediaToken, requireAdmin, verifyMediaToken } from '../auth.js';
import { AiSetupError, cleanAssistantName, cleanSpeed } from '../ai/settings.js';
import { LIVE_MODEL, OpenAIError, createWebrtcSession, extractCallResult, fetchRecording } from '../ai/openai.js';
import { SAMPLE_LEAD, VARIABLES, VOICES, buildInstructions } from '../ai/prompt.js';
import { streamCartesiaText } from '../ai/cartesia.js';

const LEAD_FIELDS = ['firstName', 'lastName', 'projectType', 'homeowner', 'county', 'zipCode', 'timeline', 'paymentPreference', 'financingInterest', 'phone', 'email', 'landingPage', 'utmSource', 'utmCampaign', 'createdAt'];

const pickLead = (src = {}) =>
  Object.fromEntries(
    LEAD_FIELDS.filter((k) => src[k] !== undefined).map((k) => [k, k === 'financingInterest' ? Boolean(src[k]) : String(src[k]).slice(0, 200)])
  );

/** Lead Desk → AI Calls: settings, scripts, browser test and starting AI phone calls. */
export function aiRoutes({ store, aiSettings, aiCalls, logger = console }) {
  const r = Router();
  const limiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 60, standardHeaders: 'draft-8', legacyHeaders: false });

  const handle = (fn) => async (req, res) => {
    try {
      res.json((await fn(req)) ?? { ok: true });
    } catch (err) {
      if (err instanceof AiSetupError || err instanceof OpenAIError) return res.status(err.status || 400).json({ error: err.message });
      logger.error('[ai]', err);
      res.status(500).json({ error: 'Something went wrong.' });
    }
  };

  /** Lead for tests: a real lead (by id), or variables typed in the panel. */
  async function testLead(body) {
    if (body.leadId) {
      const lead = await store.getLead(String(body.leadId));
      if (!lead) throw new AiSetupError('Lead not found.', 404);
      return lead;
    }
    return { ...SAMPLE_LEAD, ...pickLead(body.lead) };
  }

  /** Name/speed overrides from the test panel (volume is applied in the browser). */
  const voiceOptsFrom = (body, script) => ({
    assistantName: typeof body.assistantName === 'string' ? cleanAssistantName(body.assistantName) : script.assistantName || '',
    speed: body.speed ? cleanSpeed(body.speed) : script.speed || 'normal',
    language: body.language === 'he' || body.language === 'en' ? body.language : script.language || 'en',
  });

  async function scriptFor(body, lead) {
    // Unsaved text from the editor can be previewed/tested directly.
    if (typeof body.scriptText === 'string' && body.scriptText.trim()) {
      return { id: '', name: 'Unsaved script', language: body.language === 'he' ? 'he' : 'en', voice: '', assistantName: body.assistantName || 'Maya', speed: body.speed || 'normal', volume: 1, strictMode: Boolean(body.strictMode), instructions: body.scriptText.slice(0, 12000) };
    }
    return aiSettings.resolveScript(lead, body.scriptId);
  }

  r.get('/ai/settings', requireAdmin, handle(async () => ({ ...(await aiSettings.view()), variables: VARIABLES, sampleLead: SAMPLE_LEAD, activeCalls: aiCalls.activeCalls() })));
  r.put('/ai/settings', requireAdmin, handle((req) => aiSettings.update(req.body || {}, req.agent)));
  r.post('/ai/settings/key', requireAdmin, limiter, handle((req) => aiSettings.saveKey(req.body?.apiKey, req.agent)));
  r.delete('/ai/settings/key', requireAdmin, handle((req) => aiSettings.removeKey(req.agent)));
  r.post('/ai/settings/cartesia-key', requireAdmin, limiter, handle((req) => aiSettings.saveCartesiaKey(req.body?.apiKey, req.agent)));
  r.delete('/ai/settings/cartesia-key', requireAdmin, handle((req) => aiSettings.removeCartesiaKey(req.agent)));

  r.post('/ai/scripts', requireAdmin, handle((req) => aiSettings.saveScript(null, req.body || {}, req.agent)));
  r.put('/ai/scripts/:id', requireAdmin, handle((req) => aiSettings.saveScript(req.params.id, req.body || {}, req.agent)));
  r.delete('/ai/scripts/:id', requireAdmin, handle((req) => aiSettings.deleteScript(req.params.id)));

  /** Exact instructions GPT-Live would receive. */
  r.post(
    '/ai/preview',
    requireAdmin,
    handle(async (req) => {
      const body = req.body || {};
      const lead = await testLead(body);
      const script = await scriptFor(body, lead);
      const settings = await aiSettings.get();
      return {
        instructions: buildInstructions({ script, lead, settings, voiceOpts: voiceOptsFrom(body, script) }),
        scriptName: script.name,
        voice: VOICES.includes(body.voice) ? body.voice : script.voice || settings.defaultVoice,
        language: voiceOptsFrom(body, script).language,
        ttsProvider: settings.ttsProvider === 'cartesia' ? 'cartesia' : 'openai',
        script: { assistantName: script.assistantName, speed: script.speed, volume: script.volume, language: script.language || 'en' },
      };
    })
  );

  /** Browser test call over WebRTC (no phone, no Twilio). */
  r.post(
    '/ai/test/session',
    requireAdmin,
    limiter,
    handle(async (req) => {
      const body = req.body || {};
      if (typeof body.sdp !== 'string' || body.sdp.length < 50 || body.sdp.length > 20000) throw new AiSetupError('Invalid WebRTC offer.');
      const key = await aiSettings.apiKey();
      if (!key) throw new AiSetupError('Add your OpenAI API key first.');
      const settings = await aiSettings.get();
      const lead = await testLead(body);
      const script = await scriptFor(body, lead);
      const voice = VOICES.includes(body.voice) ? body.voice : script.voice || settings.defaultVoice;
      const instructions = buildInstructions({ script, lead, settings, voiceOpts: voiceOptsFrom(body, script) });
      const useCartesia = settings.ttsProvider === 'cartesia';
      if (useCartesia && (!(await aiSettings.cartesiaApiKey()) || !settings.cartesiaVoiceId)) {
        throw new AiSetupError('Add a Cartesia key and voice ID, or switch the voice provider back to OpenAI.');
      }
      const session = await createWebrtcSession({
        key,
        sdp: body.sdp,
        session: {
          model: LIVE_MODEL,
          instructions,
          // GPT-Live always produces its spoken response; when Cartesia is selected
          // the client discards that media track and streams Live's transcript to TTS.
          // `output_modalities` belongs to the Realtime API and is not valid here.
          audio: { output: { voice } },
          delegation: { type: 'client' },
        },
      });
      logger.log(`[ai] browser test started by ${req.agent} (script: ${script.name}, voice: ${voice})`);
      return { sdp: session.sdp, sessionId: session.id, instructions, voice, scriptName: script.name, volume: script.volume, language: voiceOptsFrom(body, script).language, ttsProvider: useCartesia ? 'cartesia' : 'openai' };
    })
  );

  /** Cartesia audio for text-only GPT-Live browser tests (raw PCM16, 24kHz). */
  r.post('/ai/test/tts', requireAdmin, async (req, res) => {
    const text = String(req.body?.text || '').trim().slice(0, 1000);
    if (!text) return res.status(400).json({ error: 'Missing text.' });
    try {
      const [key, settings] = [await aiSettings.cartesiaApiKey(), await aiSettings.get()];
      if (!key || !settings.cartesiaVoiceId) throw new AiSetupError('Cartesia is not configured.');
      let finished = false;
      let sentAudio = false;
      const fail = (err) => {
        if (finished) return;
        finished = true;
        logger.error('[cartesia-test]', err.message);
        const message = /401|403|api.?key|unauthor/i.test(err.message)
          ? 'Cartesia rejected the API key. Replace it in Settings → AI Calls.'
          : /voice/i.test(err.message)
            ? `Cartesia could not use this voice ID: ${err.message}`
            : `Cartesia audio failed: ${err.message}`;
        if (!res.headersSent) res.status(502).json({ error: message });
        else res.end();
      };
      const close = streamCartesiaText({
        apiKey: key,
        voiceId: settings.cartesiaVoiceId,
        language: req.body?.language === 'he' ? 'he' : 'en',
        text,
        onAudio: (chunk) => {
          if (finished) return;
          if (!sentAudio) {
            sentAudio = true;
            res.setHeader('Content-Type', 'application/octet-stream');
            res.setHeader('Cache-Control', 'no-store');
          }
          res.write(chunk);
        },
        onDone: () => {
          if (!sentAudio) return fail(new Error('Cartesia returned no audio. Check the voice ID and language.'));
          if (finished) return;
          finished = true;
          res.end();
        },
        onError: fail,
      });
      res.on('close', () => {
        if (!finished) close();
        finished = true;
      });
    } catch (err) {
      res.status(err.status || 500).json({ error: err.message || 'Cartesia TTS failed.' });
    }
  });

  /** Run the same do-not-call check real calls use, on a browser test transcript. */
  r.post(
    '/ai/test/result',
    requireAdmin,
    limiter,
    handle(async (req) => {
      const body = req.body || {};
      const transcript = (Array.isArray(body.transcript) ? body.transcript : [])
        .slice(0, 400)
        .map((t) => ({ role: t.role === 'agent' ? 'agent' : 'customer', text: String(t.text || '').slice(0, 2000) }))
        .filter((t) => t.text.trim());
      if (!transcript.length) throw new AiSetupError('There is no conversation to check yet.');
      const key = await aiSettings.apiKey();
      if (!key) throw new AiSetupError('Add your OpenAI API key first.');
      const settings = await aiSettings.get();
      return extractCallResult({
        key,
        model: settings.summaryModel,
        transcript,
        slots: Array.isArray(body.slots) ? body.slots.slice(0, 10) : [],
        nowText: new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', dateStyle: 'full', timeStyle: 'short' }).format(new Date()),
      });
    })
  );

  // ── Call recordings (streamed through the server; Twilio links stay private) ──
  r.post(
    '/leads/:id/recording-token',
    requireAdmin,
    handle(async (req) => {
      const activityId = String(req.body?.activityId || '');
      const entry = await store.getActivity(req.params.id, activityId);
      if (!entry?.recordingSid) throw new AiSetupError('This call has no recording.', 404);
      return { token: issueMediaToken({ leadId: req.params.id, activityId, recordingSid: entry.recordingSid }), duration: entry.recordingDuration || 0 };
    })
  );

  r.get('/recordings/play', async (req, res) => {
    const claims = verifyMediaToken(String(req.query.token || ''));
    if (!claims) return res.status(401).json({ error: 'This recording link expired. Reopen the lead.' });
    const creds = aiCalls.recordingCreds(claims.leadId, claims.activityId);
    if (!creds) return res.status(404).json({ error: 'No Twilio profile to read the recording with.' });
    try {
      const upstream = await fetchRecording({
        accountSid: creds.accountSid,
        authToken: creds.authToken,
        recordingSid: claims.recordingSid,
        range: req.headers.range,
      });
      if (!upstream.ok && upstream.status !== 206) return res.status(upstream.status === 404 ? 404 : 502).json({ error: 'Twilio could not return this recording.' });
      res.status(upstream.status);
      for (const h of ['content-type', 'content-length', 'accept-ranges', 'content-range']) {
        const v = upstream.headers.get(h);
        if (v) res.setHeader(h, v);
      }
      res.setHeader('Cache-Control', 'private, max-age=300');
      const reader = upstream.body.getReader();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(Buffer.from(value));
      }
      res.end();
    } catch (err) {
      logger.error('[recording]', err.message);
      if (!res.headersSent) res.status(502).json({ error: 'Could not load the recording.' });
    }
  });

  // ── Real AI phone calls ──
  r.post('/leads/:id/ai-call', requireAdmin, limiter, handle((req) => aiCalls.start({ leadId: req.params.id, scriptId: req.body?.scriptId, voice: VOICES.includes(req.body?.voice) ? req.body.voice : '', agent: req.agent })));
  r.post(
    '/ai/calls/:callId/hangup',
    requireAdmin,
    handle(async (req) => ({ ok: await aiCalls.hangupById(req.params.callId) }))
  );

  /** Do-not-call flag (set automatically by AI calls, or by an agent). */
  r.patch(
    '/leads/:id/dnc',
    requireAdmin,
    handle(async (req) => {
      const lead = await store.getLead(req.params.id);
      if (!lead) throw new AiSetupError('Lead not found.', 404);
      const on = Boolean(req.body?.doNotCall);
      await store.updateLead(req.params.id, { doNotCall: on, doNotCallAt: new Date().toISOString(), doNotCallSource: `agent:${req.agent}` });
      await store.addActivity(req.params.id, { type: 'note', text: on ? 'Marked Do Not Call.' : 'Removed Do Not Call flag.', agent: req.agent });
      return { ok: true };
    })
  );

  return r;
}
