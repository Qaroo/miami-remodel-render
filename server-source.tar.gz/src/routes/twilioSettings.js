import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { requireAdmin } from '../auth.js';
import { TwilioSetupError } from '../twilio/accountApi.js';

/** Lead Desk → Settings → Twilio profiles (one active profile for the whole team). */
export function twilioSettingsRoutes({ profiles, logger = console }) {
  const r = Router();
  const limiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 30, standardHeaders: 'draft-8', legacyHeaders: false });

  const handle = (fn) => async (req, res) => {
    try {
      res.json((await fn(req)) ?? { ok: true });
    } catch (err) {
      if (err instanceof TwilioSetupError) return res.status(err.status).json({ error: err.message });
      logger.error('[twilio settings]', err);
      res.status(500).json({ error: 'Something went wrong while saving Twilio settings.' });
    }
  };

  r.get('/settings/twilio', requireAdmin, handle(() => profiles.list()));
  r.post('/settings/twilio/lookup', requireAdmin, limiter, handle((req) => profiles.lookup(req.body || {})));
  r.post('/settings/twilio/profiles', requireAdmin, limiter, handle((req) => profiles.create(req.body || {}, req.agent)));
  r.post('/settings/twilio/profiles/:id/activate', requireAdmin, limiter, handle((req) => profiles.activate(req.params.id, req.agent)));
  r.post('/settings/twilio/deactivate', requireAdmin, handle((req) => profiles.deactivate(req.agent)));
  r.post('/settings/twilio/sync', requireAdmin, limiter, handle(() => profiles.syncVoiceUrl()));
  r.delete('/settings/twilio/profiles/:id', requireAdmin, limiter, handle((req) => profiles.remove(req.params.id, req.agent)));

  return r;
}
