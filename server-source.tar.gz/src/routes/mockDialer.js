import { Router } from 'express';
import { requireAdmin } from '../auth.js';

/**
 * Simulated calls for local testing (MOCK_MODE=1 with no Twilio profile active).
 * Emits the same socket events as real Twilio webhooks.
 */
export function mockDialerRoutes({ store, calls, profiles }) {
  const r = Router();
  const active = new Map(); // activityId -> { leadId, timers, answeredAt }

  const guard = (req, res, next) => {
    if (profiles.status().mode !== 'mock') return res.status(404).json({ error: 'The test dialer only runs in MOCK_MODE without Twilio.' });
    next();
  };

  r.post('/mock-call/start', requireAdmin, guard, async (req, res) => {
    const leadId = String(req.body?.leadId || '');
    const lead = await store.getLead(leadId);
    if (!lead) return res.status(404).json({ error: 'lead not found' });
    if (lead.doNotCall) return res.status(400).json({ error: 'This lead asked not to be called.' });
    const activityId = await calls.startCall({ leadId, agent: req.agent, to: lead.phone, callSid: `MOCK${Date.now()}` });
    const state = { leadId, timers: [], answeredAt: 0 };
    state.timers.push(setTimeout(() => calls.updateCall({ leadId, activityId, status: 'ringing' }), 1200));
    state.timers.push(
      setTimeout(() => {
        state.answeredAt = Date.now();
        calls.updateCall({ leadId, activityId, status: 'in-progress' });
      }, 3500)
    );
    active.set(activityId, state);
    res.json({ ok: true, activityId });
  });

  r.post('/mock-call/:activityId/hangup', requireAdmin, guard, async (req, res) => {
    const state = active.get(req.params.activityId);
    if (!state) return res.json({ ok: true });
    state.timers.forEach(clearTimeout);
    active.delete(req.params.activityId);
    const duration = state.answeredAt ? Math.round((Date.now() - state.answeredAt) / 1000) : 0;
    await calls.updateCall({
      leadId: state.leadId,
      activityId: req.params.activityId,
      status: state.answeredAt ? 'completed' : 'canceled',
      duration,
    });
    res.json({ ok: true });
  });

  return r;
}
