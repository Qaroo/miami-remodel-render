import { Router } from 'express';
import { requireAdmin } from '../auth.js';
import { APPOINTMENT_STATUSES, CalendarError } from '../calendar.js';

/** Lead Desk → Calendar: in-house appointments (one shared calendar, Miami time). */
export function calendarRoutes({ calendar, logger = console }) {
  const r = Router();

  const handle = (fn) => async (req, res) => {
    try {
      res.json((await fn(req)) ?? { ok: true });
    } catch (err) {
      if (err instanceof CalendarError) return res.status(err.status).json({ error: err.message });
      logger.error('[calendar]', err);
      res.status(500).json({ error: 'Something went wrong.' });
    }
  };

  r.get(
    '/calendar',
    requireAdmin,
    handle(async (req) => ({
      settings: await calendar.settings(),
      statuses: APPOINTMENT_STATUSES,
      appointments: await calendar.list({ from: req.query.from, to: req.query.to }),
    }))
  );

  r.put('/calendar/settings', requireAdmin, handle((req) => calendar.updateSettings(req.body || {}, req.agent)));

  r.get(
    '/calendar/slots',
    requireAdmin,
    handle(async (req) => ({ slots: await calendar.openSlots({ limit: Math.min(200, Number(req.query.limit) || 60), skipAppointmentId: req.query.skip || '' }) }))
  );

  r.post(
    '/calendar/appointments',
    requireAdmin,
    handle((req) =>
      calendar.book({
        leadId: String(req.body?.leadId || ''),
        start: req.body?.start,
        source: 'agent',
        agent: req.agent,
        allOwnersConfirmed: req.body?.allOwnersConfirmed,
        notes: req.body?.notes,
      })
    )
  );

  r.patch('/calendar/appointments/:id', requireAdmin, handle((req) => calendar.update(req.params.id, req.body || {}, req.agent)));

  r.get('/leads/:id/appointments', requireAdmin, handle((req) => calendar.forLead(req.params.id)));

  return r;
}
