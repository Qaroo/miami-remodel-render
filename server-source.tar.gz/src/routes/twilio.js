import crypto from 'node:crypto';
import express, { Router } from 'express';
import twilio from 'twilio';
import { requireAdmin } from '../auth.js';
import { config } from '../config.js';
import { callingWindow } from '../leads.js';
import { baseUrlFor, runtime } from '../runtime.js';
import { accountApi } from '../twilio/accountApi.js';

const { AccessToken } = twilio.jwt;
const { VoiceGrant } = AccessToken;
const { VoiceResponse } = twilio.twiml;

/** Twilio client identities look like: agent_<slug>_<random> */
const identityFor = (agent) =>
  `agent_${agent.toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 24) || 'user'}_${crypto.randomBytes(3).toString('hex')}`;

/** Verify the X-Twilio-Signature header with the active profile's Auth Token. */
const verifyTwilio = (profiles) => (req, res, next) => {
  const p = profiles.active();
  if (!p) return res.status(404).type('text/plain').send('Twilio is not configured');
  if (config.twilio.skipSignature) return next();
  const signature = req.get('x-twilio-signature') || '';
  // Twilio signs the exact URL it called: try the published URL and the host it reached.
  const host = req.get('x-forwarded-host') || req.get('host');
  const candidates = [...new Set([runtime.publicUrl && `${runtime.publicUrl}${req.originalUrl}`, `https://${host}${req.originalUrl}`].filter(Boolean))];
  const ok =
    Boolean(signature) &&
    candidates.some((url) => {
      try {
        return twilio.validateRequest(p.authToken, signature, url, req.body || {});
      } catch {
        return false;
      }
    });
  if (!ok) return res.status(403).type('text/plain').send('Invalid Twilio signature');
  next();
};

export function twilioRoutes({ store, calls, profiles, aiCalls, realtime, logger = console }) {
  const api = Router();
  const hooks = Router();
  const verify = verifyTwilio(profiles);
  hooks.use(express.urlencoded({ extended: false }));

  // ── Browser softphone token ─────────────────────────
  api.post('/twilio/token', requireAdmin, (req, res) => {
    const p = profiles.active();
    if (!p) return res.json({ mode: profiles.status().mode });
    const identity = identityFor(req.agent);
    const token = new AccessToken(p.accountSid, p.apiKeySid, p.apiKeySecret, { identity, ttl: 3600 });
    token.addGrant(new VoiceGrant({ outgoingApplicationSid: p.twimlAppSid, incomingAllow: false }));
    res.json({ mode: 'live', token: token.toJwt(), identity, expiresIn: 3600, profileId: p.id });
  });

  const iso = (value) => {
    if (!value) return new Date().toISOString();
    const date = value instanceof Date ? value : new Date(value);
    return Number.isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
  };
  const cleanPhone = (value) => String(value || '').replace(/[^\d+]/g, '');
  const fromTwilio = async (message, profile) => {
    const direction = String(message.direction || '').startsWith('inbound') ? 'inbound' : 'outbound';
    const contactPhone = cleanPhone(direction === 'inbound' ? message.from : message.to);
    const lead = contactPhone ? await store.findLeadByPhone(contactPhone) : null;
    return {
      id: message.sid,
      sid: message.sid,
      profileId: profile.id,
      leadId: lead?.id || '',
      leadName: lead ? `${lead.firstName || ''} ${lead.lastName || ''}`.trim() : '',
      contactPhone,
      from: cleanPhone(message.from),
      to: cleanPhone(message.to),
      body: String(message.body || '').slice(0, 1600),
      direction,
      status: String(message.status || (direction === 'inbound' ? 'received' : 'queued')),
      errorCode: message.errorCode ? String(message.errorCode) : '',
      errorMessage: String(message.errorMessage || '').slice(0, 500),
      createdAt: iso(message.dateSent || message.dateCreated),
    };
  };

  const syncMessages = async () => {
    const p = profiles.active();
    if (!p) return { synced: 0, warning: 'Twilio is not configured.' };
    const all = await accountApi.listMessages({ accountSid: p.accountSid, authToken: p.authToken, limit: 250 });
    const messages = all.filter((message) => cleanPhone(message.from) === p.callerId || cleanPhone(message.to) === p.callerId);
    for (const raw of messages) await store.upsertSms(raw.sid, await fromTwilio(raw, p));
    return { synced: messages.length };
  };

  api.get('/sms', requireAdmin, async (req, res) => {
    let sync = { synced: 0 };
    if (req.query.sync !== '0') {
      try {
        sync = await syncMessages();
      } catch (err) {
        logger.error('[twilio sms] history sync failed', err);
        sync = { synced: 0, warning: err.message };
      }
    }
    const leadId = String(req.query.leadId || '');
    res.json({ messages: await store.listSms({ leadId, limit: 400 }), ...sync });
  });

  api.post('/sms/send', requireAdmin, async (req, res) => {
    try {
      const p = profiles.active();
      if (!p) return res.status(400).json({ error: 'Connect Twilio in Settings before sending SMS.' });
      const lead = await store.getLead(String(req.body?.leadId || ''));
      if (!lead) return res.status(404).json({ error: 'Lead not found.' });
      if (lead.doNotText || await store.phoneOptOut?.(lead.phone, 'doNotText')) return res.status(400).json({ error: 'This lead opted out of text messages.' });
      if (!/^\+1\d{10}$/.test(lead.phone || '')) return res.status(400).json({ error: 'This lead does not have a valid US phone number.' });
      const body = String(req.body?.body || '').trim().slice(0, 1600);
      if (!body) return res.status(400).json({ error: 'Write a message first.' });
      const base = baseUrlFor(req);
      const raw = await accountApi.sendMessage({
        accountSid: p.accountSid,
        authToken: p.authToken,
        from: p.callerId,
        to: lead.phone,
        body,
        statusCallback: `${base}/twilio/sms/status`,
      });
      const item = await store.upsertSms(raw.sid, {
        ...(await fromTwilio({ ...raw, body, from: p.callerId, to: lead.phone }, p)),
        leadId: lead.id,
        leadName: `${lead.firstName || ''} ${lead.lastName || ''}`.trim(),
        agent: req.agent,
      });
      realtime?.emitSms?.(item);
      res.status(201).json(item);
    } catch (err) {
      logger.error('[twilio sms] send failed', err);
      res.status(err.status || 502).json({ error: err.message || 'Could not send this text message.' });
    }
  });

  // ── TwiML App voice URL: called when the browser device connects ──
  hooks.post('/voice', verify, async (req, res) => {
    const vr = new VoiceResponse();
    const say = (msg) => {
      vr.say({ voice: 'Polly.Joanna' }, msg);
      res.type('text/xml').send(vr.toString());
    };

    try {
      const from = String(req.body.From || '');
      const leadId = String(req.body.leadId || '');
      const agent = String(req.body.agent || '').slice(0, 40) || 'Agent';
      const override = req.body.overrideHours === '1';

      // Only our own browser clients may place calls.
      if (!from.startsWith('client:agent_')) return say('This call is not allowed.');
      if (!leadId) return say('No lead was selected.');

      // Dial the number stored on the lead — never a number sent from the browser.
      const lead = await store.getLead(leadId);
      if (!lead?.phone || !/^\+1\d{10}$/.test(lead.phone)) return say('This lead does not have a valid phone number.');
      if (lead.doNotCall) return say('This lead asked not to be called.');

      const hours = callingWindow(config.callingHours);
      if (!hours.allowed && !override) return say('Calls to this lead are outside allowed calling hours.');

      const activityId = await calls.startCall({ leadId, agent, callSid: req.body.CallSid, to: lead.phone });
      const base = baseUrlFor(req);
      const qs = `leadId=${encodeURIComponent(leadId)}&activityId=${encodeURIComponent(activityId)}`;

      const dial = vr.dial({
        callerId: profiles.active()?.callerId,
        answerOnBridge: true,
        timeout: 30,
        action: `${base}/twilio/dial-complete?${qs}`,
        method: 'POST',
      });
      dial.number(
        {
          statusCallback: `${base}/twilio/status?${qs}`,
          statusCallbackEvent: ['initiated', 'ringing', 'answered', 'completed'],
          statusCallbackMethod: 'POST',
        },
        lead.phone
      );
      res.type('text/xml').send(vr.toString());
    } catch (err) {
      logger.error('[twilio] /voice failed', err);
      say('Sorry, we could not place this call.');
    }
  });

  hooks.post('/incoming', verify, async (req, res) => {
    try {
      const phone = cleanPhone(req.body.From);
      if (!/^\+[1-9]\d{7,14}$/.test(phone)) return res.type('text/xml').send('<Response><Say>Sorry, we cannot answer this call.</Say><Hangup/></Response>');
      let lead = await store.findLeadByPhone(phone);
      if (!lead) {
        const id = await store.createLead({ phone, firstName: 'Incoming', lastName: 'Caller', source: 'incoming_call', status: 'new', callCount: 0 });
        lead = await store.getLead(id);
      }
      const result = await aiCalls.start({ leadId: lead.id, agent: 'Incoming call', incoming: { callSid: String(req.body.CallSid) } });
      res.type('text/xml').send(result.twiml);
    } catch (err) {
      logger.error('[twilio] incoming call failed', err.message);
      const vr = new VoiceResponse();
      vr.say('Sorry, our assistant is unavailable. Please leave your name and number after the tone.');
      if (req.body.CallSid) await store.saveAiSession?.(`voicemail_${req.body.CallSid}`, { leadId: (await store.findLeadByPhone(cleanPhone(req.body.From)))?.id || '' });
      vr.record({ maxLength: 120, action: `${baseUrlFor(req)}/twilio/voicemail`, recordingStatusCallback: `${baseUrlFor(req)}/twilio/voicemail-recording` });
      res.type('text/xml').send(vr.toString());
    }
  });
  hooks.post('/voicemail', verify, (req, res) => res.type('text/xml').send('<Response><Say>Thank you. Goodbye.</Say><Hangup/></Response>'));
  hooks.post('/voicemail-recording', verify, async (req, res) => {
    const target = await store.getAiSession?.(`voicemail_${req.body.CallSid}`);
    const lead = target?.leadId ? await store.getLead(target.leadId) : await store.findLeadByPhone(cleanPhone(req.body.From));
    if (lead && req.body.RecordingSid) await store.addActivity(lead.id, { type: 'voicemail', callSid: String(req.body.CallSid || ''), recordingSid: String(req.body.RecordingSid), recordingDuration: Number(req.body.RecordingDuration || 0), agent: 'Incoming call' });
    res.type('text/xml').send('<Response/>');
  });

  // ── Status callbacks for the outbound leg ───────────
  hooks.post('/status', verify, async (req, res) => {
    const { leadId, activityId } = req.query;
    try {
      if (leadId && activityId) {
        await calls.updateCall({
          leadId: String(leadId),
          activityId: String(activityId),
          status: req.body.CallStatus,
          duration: req.body.CallDuration,
          childCallSid: req.body.CallSid,
        });
      }
    } catch (err) {
      logger.error('[twilio] /status failed', err);
    }
    res.type('text/xml').send('<Response/>');
  });

  // ── <Dial action>: final outcome of the dial ─────────
  hooks.post('/dial-complete', verify, async (req, res) => {
    const { leadId, activityId } = req.query;
    try {
      if (leadId && activityId) {
        await calls.updateCall({
          leadId: String(leadId),
          activityId: String(activityId),
          // DialCallStatus "answered" here means the call was bridged and has now ended.
          status: req.body.DialCallStatus === 'answered' ? 'completed' : req.body.DialCallStatus,
          duration: req.body.DialCallDuration,
        });
      }
    } catch (err) {
      logger.error('[twilio] /dial-complete failed', err);
    }
    res.type('text/xml').send('<Response><Hangup/></Response>');
  });

  // ── AI calls (see ai/calls.js) ─────────────────────
  hooks.post('/ai-status', verify, async (req, res) => {
    try {
      await aiCalls?.onStatus(String(req.query.callId || ''), req.body || {});
    } catch (err) {
      logger.error('[twilio] /ai-status failed', err);
    }
    res.type('text/xml').send('<Response/>');
  });

  hooks.post('/ai-recording', verify, async (req, res) => {
    try {
      await aiCalls?.onRecording(String(req.query.callId || ''), req.body || {});
    } catch (err) {
      logger.error('[twilio] /ai-recording failed', err);
    }
    res.type('text/xml').send('<Response/>');
  });

  hooks.post('/ai-amd', verify, async (req, res) => {
    try {
      await aiCalls?.onAmd(String(req.query.callId || ''), req.body || {});
    } catch (err) {
      logger.error('[twilio] /ai-amd failed', err);
    }
    res.type('text/xml').send('<Response/>');
  });

  hooks.post('/sms/incoming', verify, async (req, res) => {
    try {
      const p = profiles.active();
      if (!p) return res.type('text/xml').send('<Response/>');
      const raw = {
        sid: String(req.body.MessageSid || req.body.SmsSid || ''),
        from: req.body.From,
        to: req.body.To,
        body: req.body.Body,
        status: req.body.SmsStatus || 'received',
        direction: 'inbound',
        dateCreated: new Date(),
      };
      if (raw.sid) {
        const contactPhone = cleanPhone(raw.from);
        if (/^\+[1-9]\d{7,14}$/.test(contactPhone) && !await store.findLeadByPhone(contactPhone)) {
          await store.createLead({ phone: contactPhone, firstName: 'SMS', lastName: 'Contact', source: 'incoming_sms', status: 'new', callCount: 0 });
        }
        const normalized = await fromTwilio(raw, p);
        const item = await store.upsertSms(raw.sid, normalized);
        const command = normalized.body.trim().toUpperCase();
        if (item.leadId && ['STOP', 'UNSUBSCRIBE', 'CANCEL', 'END', 'QUIT', 'STOPALL'].includes(command)) {
          await (store.setPhoneOptOut ? store.setPhoneOptOut(normalized.contactPhone, { doNotText: true, doNotTextAt: new Date().toISOString(), doNotTextSource: 'twilio_opt_out' }) : store.updateLead(item.leadId, { doNotText: true }));
        } else if (item.leadId && ['START', 'UNSTOP'].includes(command)) {
          await (store.setPhoneOptOut ? store.setPhoneOptOut(normalized.contactPhone, { doNotText: false, doNotTextAt: new Date().toISOString(), doNotTextSource: 'twilio_opt_in' }) : store.updateLead(item.leadId, { doNotText: false }));
        }
        realtime?.emitSms?.(item);
      }
    } catch (err) {
      logger.error('[twilio sms] incoming failed', err);
      return res.status(500).send('Retry later');
    }
    res.type('text/xml').send('<Response/>');
  });

  hooks.post('/sms/status', verify, async (req, res) => {
    try {
      const sid = String(req.body.MessageSid || '');
      if (sid) {
        const previous = await store.getSms(sid);
        const item = await store.upsertSms(sid, {
          status: String(req.body.MessageStatus || req.body.SmsStatus || previous?.status || ''),
          errorCode: req.body.ErrorCode ? String(req.body.ErrorCode) : '',
          errorMessage: String(req.body.ErrorMessage || '').slice(0, 500),
        });
        realtime?.emitSms?.(item);
      }
    } catch (err) {
      logger.error('[twilio sms] status failed', err);
      return res.status(500).send('Retry later');
    }
    res.type('text/xml').send('<Response/>');
  });

  return { api, hooks };
}
