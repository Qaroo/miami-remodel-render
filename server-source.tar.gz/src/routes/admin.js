import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { checkPassword, cleanAgentName, issueSession, requireAdmin } from '../auth.js';
import { config } from '../config.js';
import { runtime } from '../runtime.js';
import { LEAD_STATUSES, callingWindow, pickPublicLead, validatePublicLead } from '../leads.js';

export function adminRoutes({ store, realtime, profiles }) {
  const r = Router();

  // ── Auth ─────────────────────────────────────────────
  const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-8', legacyHeaders: false });

  r.post('/auth/login', loginLimiter, (req, res) => {
    const { password, agentName } = req.body || {};
    const agent = cleanAgentName(agentName);
    if (!agent || agent.length < 2) return res.status(400).json({ error: 'Please enter your name.' });
    if (!checkPassword(password)) return res.status(401).json({ error: 'Incorrect password.' });
    res.json({ token: issueSession(agent), agent });
  });

  r.get('/auth/me', requireAdmin, (req, res) => {
    res.json({
      agent: req.agent,
      twilio: profiles.status().mode, // live | mock | off
      twilioProfile: profiles.status().profileName || '',
      publicUrl: runtime.publicUrl,
      callingWindow: callingWindow(config.callingHours),
      statuses: LEAD_STATUSES,
    });
  });

  // ── Leads (admin) ────────────────────────────────────
  r.get('/leads', requireAdmin, async (req, res) => {
    res.json(await store.listLeads(500));
  });

  r.post('/leads/manual', requireAdmin, async (req, res) => {
    const clean = (value, max = 300) => String(value ?? '').trim().slice(0, max);
    const digits = clean(req.body?.phone, 30).replace(/\D/g, '').replace(/^1(?=\d{10}$)/, '');
    const phone = digits.length === 10 ? `+1${digits}` : '';
    const firstName = clean(req.body?.firstName, 80);
    const lastName = clean(req.body?.lastName, 80);
    if (!firstName) return res.status(400).json({ error: 'First name is required.' });
    if (!phone) return res.status(400).json({ error: 'Enter a valid 10-digit US phone number.' });
    if (await store.findLeadByPhone(phone)) return res.status(409).json({ error: 'A lead with this phone number already exists.' });
    const status = LEAD_STATUSES.includes(req.body?.status) ? req.body.status : 'new';
    const id = await store.createLead({
      firstName,
      lastName,
      phone,
      email: clean(req.body?.email, 200),
      projectType: clean(req.body?.projectType, 80) || 'General Remodeling',
      homeowner: clean(req.body?.homeowner, 20) || 'Unknown',
      county: clean(req.body?.county, 80),
      city: clean(req.body?.city, 80),
      address: clean(req.body?.address, 200),
      zipCode: clean(req.body?.zipCode, 12).replace(/\D/g, '').slice(0, 5),
      timeline: clean(req.body?.timeline, 80),
      paymentPreference: clean(req.body?.paymentPreference, 80),
      financingInterest: Boolean(req.body?.financingInterest),
      status,
      source: 'manual',
      createdBy: req.agent,
      callCount: 0,
    });
    res.status(201).json({ ok: true, id, lead: await store.getLead(id) });
  });

  r.delete('/leads/:id', requireAdmin, async (req, res) => {
    const lead = await store.getLead(req.params.id);
    if (!lead) return res.status(404).json({ error: 'Lead not found.' });
    await store.deleteLead(req.params.id);
    realtime.emitLeadRemoved(req.params.id);
    res.json({ ok: true });
  });

  const importLimiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 80, standardHeaders: 'draft-8', legacyHeaders: false });
  r.post('/leads/import', requireAdmin, importLimiter, async (req, res) => {
    const rows = Array.isArray(req.body?.leads) ? req.body.leads.slice(0, 100) : [];
    if (!rows.length) return res.status(400).json({ error: 'No leads were supplied.' });
    const result = { created: 0, duplicates: 0, invalid: 0, ids: [] };
    const clean = (value, max = 300) => String(value ?? '').trim().slice(0, max);
    for (const input of rows) {
      const phone = clean(input.phone, 20);
      const firstName = clean(input.firstName, 80);
      const lastName = clean(input.lastName, 80);
      if (!/^\+1\d{10}$/.test(phone) || !firstName) {
        result.invalid += 1;
        continue;
      }
      if (await store.findLeadByPhone(phone)) {
        result.duplicates += 1;
        continue;
      }
      const status = LEAD_STATUSES.includes(input.status) ? input.status : 'new';
      const lead = {
        firstName,
        lastName,
        phone,
        email: clean(input.email, 200),
        projectType: clean(input.projectType, 80) || 'General Remodeling',
        homeowner: clean(input.homeowner, 20) || 'Unknown',
        county: clean(input.county, 80),
        city: clean(input.city, 80),
        address: clean(input.address, 200),
        zipCode: clean(input.zipCode, 12),
        timeline: clean(input.timeline, 80),
        paymentPreference: clean(input.paymentPreference, 80),
        financingInterest: Boolean(input.financingInterest),
        doNotCall: Boolean(input.doNotCall),
        doNotText: Boolean(input.doNotText),
        status,
        source: 'excel_import',
        importFile: clean(input.importFile, 180),
        importedBy: req.agent,
        importedAt: new Date().toISOString(),
        externalId: clean(input.externalId, 120),
        utmSource: clean(input.utmSource, 120),
        utmMedium: clean(input.utmMedium, 120),
        utmCampaign: clean(input.utmCampaign, 300),
        utmContent: clean(input.utmContent, 300),
        callCount: 0,
        importData: input.importData && typeof input.importData === 'object' ? input.importData : {},
      };
      const id = await store.createLead(lead);
      result.created += 1;
      result.ids.push(id);
    }
    res.status(201).json(result);
  });

  r.get('/leads/:id/activity', requireAdmin, async (req, res) => {
    const lead = await store.getLead(req.params.id);
    if (!lead) return res.status(404).json({ error: 'not found' });
    res.json(await store.listActivity(req.params.id));
  });

  r.patch('/leads/:id', requireAdmin, async (req, res) => {
    const { status } = req.body || {};
    if (!LEAD_STATUSES.includes(status)) return res.status(400).json({ error: 'invalid status' });
    const lead = await store.getLead(req.params.id);
    if (!lead) return res.status(404).json({ error: 'not found' });
    if (lead.status === status) return res.json({ ok: true });
    await store.updateLead(req.params.id, { status, statusChangedBy: req.agent });
    const activityId = await store.addActivity(req.params.id, { type: 'status', from: lead.status || 'new', to: status, agent: req.agent });
    realtime.emitActivity(req.params.id, await store.getActivity(req.params.id, activityId));
    res.json({ ok: true });
  });

  r.post('/leads/:id/notes', requireAdmin, async (req, res) => {
    const text = String(req.body?.text || '').trim().slice(0, 2000);
    if (!text) return res.status(400).json({ error: 'empty note' });
    const lead = await store.getLead(req.params.id);
    if (!lead) return res.status(404).json({ error: 'not found' });
    const activityId = await store.addActivity(req.params.id, { type: 'note', text, agent: req.agent });
    await store.updateLead(req.params.id, { lastNoteAt: new Date().toISOString() });
    realtime.emitActivity(req.params.id, await store.getActivity(req.params.id, activityId));
    res.json({ ok: true, id: activityId });
  });

  // ── Public lead intake (optional alternative to direct Firestore writes) ──
  const intakeLimiter = rateLimit({ windowMs: 60 * 1000, limit: 6, standardHeaders: 'draft-8', legacyHeaders: false });

  r.post('/public/leads', intakeLimiter, async (req, res) => {
    const body = req.body || {};
    if (body.company) return res.json({ ok: true }); // honeypot
    const errors = validatePublicLead(body);
    if (errors.length) return res.status(400).json({ error: 'invalid lead', fields: errors });
    const id = await store.createLead(pickPublicLead(body));
    res.status(201).json({ ok: true, id });
  });

  return r;
}
