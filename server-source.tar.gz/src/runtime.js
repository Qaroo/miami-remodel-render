import { EventEmitter } from 'node:events';
import { config } from './config.js';

/**
 * Live server state that can change while running:
 *  - publicUrl: the https address Twilio and the admin panel use (tunnel URL or PUBLIC_BASE_URL)
 */
const events = new EventEmitter();
let publicUrl = config.tunnel ? '' : config.publicBaseUrl;

export const runtime = {
  get publicUrl() {
    return publicUrl;
  },
  setPublicUrl(url) {
    const next = String(url || '').replace(/\/+$/, '');
    if (next === publicUrl) return;
    publicUrl = next;
    events.emit('publicUrl', next);
  },
  onPublicUrl(fn) {
    events.on('publicUrl', fn);
    return () => events.off('publicUrl', fn);
  },
};

/** The public base URL for Twilio callbacks: the known public URL, else the host Twilio just reached. */
export function baseUrlFor(req) {
  if (runtime.publicUrl) return runtime.publicUrl;
  const host = req.get('x-forwarded-host') || req.get('host');
  return `https://${host}`;
}
