import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { config } from './config.js';

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();

/** Constant-time comparison against the shared admin password. */
export function checkPassword(candidate) {
  if (!config.admin.password) return false;
  return crypto.timingSafeEqual(sha(candidate), sha(config.admin.password));
}

export function cleanAgentName(name) {
  return String(name || '')
    .replace(/[^\p{L}\p{N} .'-]/gu, '')
    .trim()
    .slice(0, 40);
}

export function issueSession(agentName) {
  return jwt.sign({ agent: agentName, role: 'admin' }, config.admin.sessionSecret, {
    expiresIn: `${config.admin.sessionHours}h`,
    audience: 'miami-remodel-admin',
  });
}

export function verifySession(token) {
  try {
    const payload = jwt.verify(token, config.admin.sessionSecret, { audience: 'miami-remodel-admin' });
    return payload?.role === 'admin' ? payload : null;
  } catch {
    return null;
  }
}

/** Short-lived token so an <audio> tag can stream a recording (no headers possible). */
export function issueMediaToken(payload) {
  return jwt.sign(payload, config.admin.sessionSecret, { expiresIn: '15m', audience: 'miami-remodel-media' });
}

export function verifyMediaToken(token) {
  try {
    return jwt.verify(token, config.admin.sessionSecret, { audience: 'miami-remodel-media' });
  } catch {
    return null;
  }
}

/** Express middleware — requires `Authorization: Bearer <session>`. */
export function requireAdmin(req, res, next) {
  const header = req.get('authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const session = verifySession(token);
  if (!session) return res.status(401).json({ error: 'unauthorized' });
  req.agent = session.agent;
  next();
}
