import crypto from 'node:crypto';
import WebSocket from 'ws';

export const CARTESIA_MODEL = 'sonic-3.6';
export const CARTESIA_VERSION = '2026-08-14';
export const CARTESIA_SPEED = 1.25;
const URL = `wss://api.cartesia.ai/tts/websocket?cartesia_version=${CARTESIA_VERSION}`;

const lang = (value) => (value === 'he' ? 'he' : 'en');

/**
 * Streaming Cartesia connection. Text fragments from one Live-model response share
 * a context, so Sonic keeps prosody continuous while it starts speaking early.
 */
export function openCartesiaTts({
  apiKey,
  voiceId,
  language = 'en',
  outputFormat,
  maxBufferDelayMs = 120,
  speed = CARTESIA_SPEED,
  onAudio,
  onDone = () => {},
  onError = () => {},
}) {
  const ws = new WebSocket(URL, { headers: { 'X-Api-Key': apiKey } });
  const pending = [];
  const contexts = new Map();
  let activeContext = '';
  let closed = false;

  const send = (payload) => {
    if (closed) return;
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
    else if (ws.readyState === WebSocket.CONNECTING) pending.push(payload);
  };

  const base = (contextId) => ({
    model_id: CARTESIA_MODEL,
    voice: voiceId,
    language: lang(language),
    output_format: outputFormat,
    context_id: contextId,
    max_buffer_delay_ms: Math.max(0, Math.min(5000, Number(maxBufferDelayMs) || 0)),
    generation_config: { speed },
  });

  const contextFor = (responseId = 'default') => {
    if (!contexts.has(responseId)) contexts.set(responseId, crypto.randomUUID());
    return contexts.get(responseId);
  };

  ws.on('open', () => {
    while (pending.length) ws.send(JSON.stringify(pending.shift()));
  });
  ws.on('message', (raw) => {
    let event;
    try {
      event = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (event.type === 'chunk' && event.data && (!activeContext || event.context_id === activeContext)) onAudio(Buffer.from(event.data, 'base64'));
    else if (event.type === 'done' && (!activeContext || event.context_id === activeContext)) onDone(event);
    else if (event.type === 'error') {
      const detail = typeof event.error === 'string' ? event.error : event.error?.message;
      onError(new Error(event.message || detail || 'Cartesia TTS error'));
    }
  });
  ws.on('error', onError);

  return {
    push(text, responseId = 'default') {
      if (!text) return;
      const contextId = contextFor(responseId);
      activeContext = contextId;
      send({ ...base(contextId), transcript: text, continue: true });
    },
    finish(responseId = 'default') {
      const contextId = contextFor(responseId);
      send({ ...base(contextId), transcript: '', continue: false });
      contexts.delete(responseId);
    },
    cancel() {
      contexts.clear();
      activeContext = crypto.randomUUID(); // Ignore late audio from the interrupted turn.
    },
    close() {
      closed = true;
      pending.length = 0;
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) ws.close();
    },
  };
}

/** Stream one browser-test utterance as raw signed 16-bit PCM at 24kHz. */
export function streamCartesiaText({ apiKey, voiceId, language, text, onAudio, onDone, onError }) {
  let timer;
  let settled = false;
  const finish = (fn, value) => {
    if (settled) return;
    settled = true;
    clearTimeout(timer);
    tts.close();
    fn(value);
  };
  const tts = openCartesiaTts({
    apiKey,
    voiceId,
    language,
    outputFormat: { container: 'raw', encoding: 'pcm_s16le', sample_rate: 24000 },
    maxBufferDelayMs: 0,
    onAudio,
    onDone: () => finish(onDone),
    onError: (err) => finish(onError, err),
  });
  tts.push(text, 'test');
  tts.finish('test');
  timer = setTimeout(() => finish(onError, new Error('Cartesia did not return audio in time.')), 30000);
  return () => {
    settled = true;
    clearTimeout(timer);
    tts.close();
  };
}
