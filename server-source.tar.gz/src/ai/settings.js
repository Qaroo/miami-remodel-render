import { mask, open, seal } from '../secrets.js';
import { OpenAIError, verifyKey } from './openai.js';
import { DEFAULT_SCRIPT, PRODUCT_KEYS, SPEEDS, VOICES, productKeyFor } from './prompt.js';

export class AiSetupError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
    this.safeToRetry = status !== 502;
  }
}

const DEFAULTS = {
  businessName: 'Miami Remodel',
  businessPhone: '',
  defaultVoice: 'marin',
  summaryModel: 'gpt-5.6-luna',
  maxMinutes: 8,
  autoHangup: true,
  primaryScriptId: '',
  ttsProvider: 'openai',
  cartesiaVoiceId: '',
  defaults: {}, // productKey -> scriptId
};

const clean = (v, max) => String(v ?? '').trim().slice(0, max);

export const cleanAssistantName = (v) => clean(v, 40).replace(/[^\p{L} .'-]/gu, '').trim();
export const cleanSpeed = (v) => (SPEEDS.some((s) => s.key === v) ? v : 'normal');
export const cleanVolume = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(2, Math.max(0.5, Math.round(n * 20) / 20)) : 1;
};
const usPhone = (v) => {
  const d = String(v ?? '').replace(/\D/g, '').replace(/^1(?=\d{10}$)/, '');
  return d.length === 10 ? `+1${d}` : '';
};

/**
 * AI call settings: OpenAI key (encrypted), voice, scripts and per-product default scripts.
 */
export function createAiSettings({ store }) {
  let cache = null;

  async function load() {
    const raw = await store.getSettings('ai');
    cache = { ...DEFAULTS, ...raw, defaults: { ...(raw.defaults || {}) } };
    return cache;
  }
  const get = async () => cache || load();

  async function ensureDefaultScript() {
    const scripts = await store.listScripts();
    if (scripts.length) return scripts;
    await store.createScript({ name: 'Estimate follow-up (default)', language: 'en', voice: '', assistantName: 'Maya', speed: 'normal', volume: 1, instructions: DEFAULT_SCRIPT, createdBy: 'system' });
    return store.listScripts();
  }

  return {
    get,

    /** Decrypted OpenAI key or '' */
    async apiKey() {
      const s = await get();
      return open(s.openaiKeyEnc) || '';
    },

    /** Decrypted Cartesia key or '' */
    async cartesiaApiKey() {
      const s = await get();
      return open(s.cartesiaKeyEnc) || '';
    },

    async view() {
      const s = await get();
      const scripts = await ensureDefaultScript();
      const keyOk = Boolean(open(s.openaiKeyEnc));
      const cartesiaKeyOk = Boolean(open(s.cartesiaKeyEnc));
      return {
        hasKey: keyOk,
        keyHint: keyOk ? mask(open(s.openaiKeyEnc), 4) : '',
        keyBroken: Boolean(s.openaiKeyEnc) && !keyOk,
        keyVerifiedAt: s.keyVerifiedAt || null,
        hasCartesiaKey: cartesiaKeyOk,
        cartesiaKeyHint: cartesiaKeyOk ? mask(open(s.cartesiaKeyEnc), 4) : '',
        cartesiaKeyBroken: Boolean(s.cartesiaKeyEnc) && !cartesiaKeyOk,
        businessName: s.businessName,
        businessPhone: s.businessPhone || '',
        speeds: SPEEDS.map(({ key, label }) => ({ key, label })),
        defaultVoice: s.defaultVoice,
        summaryModel: s.summaryModel,
        maxMinutes: s.maxMinutes,
        autoHangup: s.autoHangup,
        primaryScriptId: s.primaryScriptId || '',
        ttsProvider: s.ttsProvider === 'cartesia' ? 'cartesia' : 'openai',
        cartesiaVoiceId: s.cartesiaVoiceId || '',
        defaults: s.defaults,
        voices: VOICES,
        products: PRODUCT_KEYS.map(({ key, label }) => ({ key, label })),
        scripts: scripts.map((x) => ({ language: 'en', speed: 'normal', volume: 1, ...x, assistantName: x.assistantName || 'Maya' })),
      };
    },

    async saveKey(rawKey, agent) {
      const key = clean(rawKey, 300);
      if (!/^sk-[A-Za-z0-9_\-]{20,}$/.test(key)) throw new AiSetupError('That doesn’t look like an OpenAI API key (it starts with sk-).');
      try {
        await verifyKey(key);
      } catch (err) {
        throw new AiSetupError(err.message, err instanceof OpenAIError ? err.status : 400);
      }
      await store.setSettings('ai', { openaiKeyEnc: seal(key), keyVerifiedAt: new Date().toISOString(), keyChangedBy: agent });
      await load();
    },

    async removeKey(agent) {
      await store.setSettings('ai', { openaiKeyEnc: '', keyVerifiedAt: null, keyChangedBy: agent });
      await load();
    },

    async saveCartesiaKey(rawKey, agent) {
      const key = clean(rawKey, 300);
      if (!/^sk_car_[A-Za-z0-9_\-]{12,}$/.test(key)) throw new AiSetupError('That doesn’t look like a Cartesia API key (it starts with sk_car_).');
      await store.setSettings('ai', { cartesiaKeyEnc: seal(key), cartesiaKeyChangedBy: agent });
      await load();
    },

    async removeCartesiaKey(agent) {
      await store.setSettings('ai', { cartesiaKeyEnc: '', cartesiaKeyChangedBy: agent, ttsProvider: 'openai' });
      await load();
    },

    async update(body, agent) {
      const patch = {};
      if ('businessName' in body) patch.businessName = clean(body.businessName, 60) || DEFAULTS.businessName;
      if ('businessPhone' in body) {
        const phone = usPhone(body.businessPhone);
        if (body.businessPhone && !phone) throw new AiSetupError('Enter a 10-digit US phone number for the business.');
        patch.businessPhone = phone;
      }
      if ('defaultVoice' in body) {
        if (!VOICES.includes(body.defaultVoice)) throw new AiSetupError('Unknown voice.');
        patch.defaultVoice = body.defaultVoice;
      }
      if ('summaryModel' in body) patch.summaryModel = clean(body.summaryModel, 60).replace(/[^\w.\-]/g, '') || DEFAULTS.summaryModel;
      if ('maxMinutes' in body) patch.maxMinutes = Math.min(20, Math.max(2, Math.round(Number(body.maxMinutes) || DEFAULTS.maxMinutes)));
      if ('autoHangup' in body) patch.autoHangup = Boolean(body.autoHangup);
      if ('ttsProvider' in body) {
        if (!['openai', 'cartesia'].includes(body.ttsProvider)) throw new AiSetupError('Unknown voice provider.');
        patch.ttsProvider = body.ttsProvider;
      }
      if ('cartesiaVoiceId' in body) patch.cartesiaVoiceId = clean(body.cartesiaVoiceId, 100).replace(/[^A-Za-z0-9_\-]/g, '');
      if ('primaryScriptId' in body) {
        const scripts = await store.listScripts();
        patch.primaryScriptId = scripts.some((x) => x.id === body.primaryScriptId) ? body.primaryScriptId : '';
      }
      if (body.defaults && typeof body.defaults === 'object') {
        const scripts = await store.listScripts();
        const ids = new Set(scripts.map((x) => x.id));
        const defaults = {};
        for (const { key } of PRODUCT_KEYS) {
          const id = body.defaults[key];
          if (id && ids.has(id)) defaults[key] = id;
        }
        patch.defaults = defaults;
      }
      await store.setSettings('ai', { ...patch, changedBy: agent });
      await load();
    },

    async saveScript(id, body, agent) {
      const data = {
        name: clean(body.name, 80),
        language: body.language === 'he' ? 'he' : 'en',
        voice: VOICES.includes(body.voice) ? body.voice : '',
        assistantName: cleanAssistantName(body.assistantName) || 'Maya',
        speed: cleanSpeed(body.speed),
        volume: cleanVolume(body.volume),
        strictMode: Boolean(body.strictMode),
        instructions: clean(body.instructions, 12000),
      };
      if (data.name.length < 2) throw new AiSetupError('Give the script a name.');
      if (data.instructions.length < 20) throw new AiSetupError('The script is too short.');
      if (id) {
        if (!(await store.getScript(id))) throw new AiSetupError('Script not found.', 404);
        await store.updateScript(id, { ...data, updatedBy: agent });
        return { id };
      }
      return { id: await store.createScript({ ...data, createdBy: agent }) };
    },

    async deleteScript(id) {
      const scripts = await store.listScripts();
      if (scripts.length <= 1) throw new AiSetupError('Keep at least one script.');
      await store.deleteScript(id);
      const s = await get();
      const defaults = Object.fromEntries(Object.entries(s.defaults).filter(([, v]) => v !== id));
      await store.setSettings('ai', { defaults, ...(s.primaryScriptId === id ? { primaryScriptId: '' } : {}) });
      await load();
    },

    /** The script to use: explicit choice → main script → product default → first script. */
    async resolveScript(lead, scriptId) {
      const scripts = await ensureDefaultScript();
      const s = await get();
      const byId = (id) => scripts.find((x) => x.id === id);
      const found = byId(scriptId) || byId(s.primaryScriptId) || byId(s.defaults[productKeyFor(lead?.projectType)]) || scripts[0];
      return { language: 'en', speed: 'normal', volume: 1, ...found, assistantName: found.assistantName || 'Maya' };
    },
  };
}
