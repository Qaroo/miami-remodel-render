import crypto from 'node:crypto';
import twilio from 'twilio';
import { WebSocketServer } from 'ws';
import { config } from '../config.js';
import { callingWindow } from '../leads.js';
import { runtime } from '../runtime.js';
import { accountApi } from '../twilio/accountApi.js';
import { runBridge } from './bridge.js';
import { extractCallResult } from './openai.js';
import { buildInstructions } from './prompt.js';
import { AiSetupError } from './settings.js';

const MAX_CONCURRENT = 3;
const FINAL = new Set(['completed', 'busy', 'no-answer', 'failed', 'canceled']);

/**
 * AI phone calls: Twilio dials the lead, <Connect><Stream> sends the audio to this
 * server, and the bridge relays it to GPT-Live. The call is recorded by Twilio, the
 * transcript is saved with the lead, agents can listen in live, and afterwards the
 * agreed appointment is booked on the calendar.
 *
 * Socket events → admins:
 *   ai:call        { callId, leadId, status, outcome?, agent }
 */
export function createAiCalls({ store, realtime, profiles, aiSettings, calendar, logger = console }) {
  const calls = new Map(); // callId -> state
  const byCallSid = new Map(); // Twilio CallSid -> { leadId, activityId } (for recording callbacks)

const miamiNow = () => new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', dateStyle: 'full', timeStyle: 'short' }).format(new Date());

  const emit = (state, extra = {}) =>
    realtime.io.to('admins').emit('ai:call', {
      callId: state.id,
      leadId: state.leadId,
      activityId: state.activityId,
      status: state.status,
      agent: state.agent,
      scriptName: state.scriptName,
      ...extra,
    });

  async function saveActivity(state, patch) {
    await store.updateActivity(state.leadId, state.activityId, patch);
    realtime.emitActivity(state.leadId, await store.getActivity(state.leadId, state.activityId));
  }

  async function start({ leadId, scriptId, voice, agent, incoming }) {
    const id = incoming ? crypto.createHash('sha256').update(incoming.callSid).digest('hex').slice(0, 24) : crypto.randomBytes(12).toString('hex');
    if (incoming) {
      const existing = await restore(id);
      if (existing) {
        const vr = new twilio.twiml.VoiceResponse();
        if (existing.finalized || existing.bridge) vr.hangup();
        else {
          const stream = vr.connect().stream({ url: `${runtime.publicUrl.replace(/^https/, 'wss')}/ai/stream` });
          stream.parameter({ name: 'callId', value: id });
          stream.parameter({ name: 'token', value: existing.token });
        }
        return { twiml: vr.toString(), callId: id };
      }
    }
    const [apiKey, settings] = [await aiSettings.apiKey(), await aiSettings.get()];
    const tw = profiles.active();
    if (!apiKey) throw new AiSetupError('Add your OpenAI API key in Settings → AI Calls first.');
    if (!tw) throw new AiSetupError('Turn on a Twilio profile in Settings → Calling first.');
    if (!settings.businessPhone) throw new AiSetupError('Add your business phone number in Settings → AI Calls → Call settings. The AI must give it on every call.');
    if (!/^https:\/\//.test(runtime.publicUrl)) throw new AiSetupError('The server has no public address. Configure the cloud service public URL.');

    const lead = await store.getLead(leadId);
    if (!lead) throw new AiSetupError('Lead not found.', 404);
    if (!incoming && (lead.doNotCall || await store.phoneOptOut?.(lead.phone, 'doNotCall'))) throw new AiSetupError('This lead asked not to be called.');
    if (!(incoming ? /^\+[1-9]\d{7,14}$/ : /^\+1\d{10}$/).test(lead.phone || '')) throw new AiSetupError('This lead does not have a valid US phone number.');
    const hours = callingWindow(config.callingHours);
    if (!incoming && !hours.allowed) throw new AiSetupError(`AI calls are only allowed ${config.callingHours.start}am–${config.callingHours.end - 12}pm Miami time (it's ${hours.label}).`);

    const live = [...calls.values()].filter((c) => !c.finalized);
    if (live.some((c) => c.leadId === leadId)) throw new AiSetupError('An AI call to this lead is already in progress.');
    if (live.length >= MAX_CONCURRENT) throw new AiSetupError(`Up to ${MAX_CONCURRENT} AI calls can run at the same time.`);

    const script = await aiSettings.resolveScript(lead, scriptId);
    const chosenVoice = voice || script.voice || settings.defaultVoice;
    const slots = await calendar.slotsForCall(6).catch((err) => {
      logger.error('[ai-call] could not read open slots', err.message);
      return [];
    });
    const instructions = buildInstructions({ script, lead, settings, slots });
    const cartesiaKey = settings.ttsProvider === 'cartesia' ? await aiSettings.cartesiaApiKey() : '';
    if (settings.ttsProvider === 'cartesia' && (!cartesiaKey || !settings.cartesiaVoiceId)) {
      throw new AiSetupError('Add a Cartesia key and voice ID in Settings → AI Calls, or use the OpenAI voice.');
    }

    const state = {
      id,
      token: crypto.randomBytes(24).toString('hex'),
      leadId,
      agent,
      scriptName: script.name,
      voice: chosenVoice,
      volume: script.volume || 1,
      language: script.language || 'en',
      cartesia: cartesiaKey ? { apiKey: cartesiaKey, voiceId: settings.cartesiaVoiceId, language: script.language || 'en' } : null,
      instructions: incoming ? `You are answering an incoming call to Miami Remodel. Greet the caller, ask how you can help, and do not say you are calling them or following up unless they mention a prior inquiry.\n${instructions}` : instructions,
      direction: incoming ? 'inbound' : 'outbound',
      slots,
      status: 'initiated',
      createdAt: Date.now(),
      finalized: false,
    };

    state.activityId = await store.addActivity(leadId, {
      type: 'ai_call',
      direction: incoming ? 'inbound' : 'outbound',
      status: 'initiated',
      agent,
      scriptId: script.id,
      scriptName: script.name,
      voice: chosenVoice,
      to: lead.phone,
      duration: 0,
    });
    calls.set(id, state);

    const persist = async () => {
      const { bridge, transcript, usage, twilio: creds, ...saved } = state;
      if (saved.cartesia) saved.cartesia = { ...saved.cartesia, apiKey: '' };
      await store.saveAiSession?.(id, saved);
    };
    await persist();
    const base = runtime.publicUrl;
    const vr = new twilio.twiml.VoiceResponse();
    const stream = vr.connect().stream({ url: `${base.replace(/^https/, 'wss')}/ai/stream` });
    stream.parameter({ name: 'callId', value: id });
    stream.parameter({ name: 'token', value: state.token });

    try {
      const res = incoming ? { sid: incoming.callSid } : await accountApi.placeCall({
        accountSid: tw.accountSid,
        authToken: tw.authToken,
        to: lead.phone,
        from: tw.callerId,
        twiml: vr.toString(),
        timeout: 30,
        timeLimit: settings.maxMinutes * 60 + 30,
        statusCallback: `${base}/twilio/ai-status?callId=${id}`,
        statusCallbackMethod: 'POST',
        statusCallbackEvent: ['initiated', 'ringing', 'answered', 'completed'],
        record: true,
        recordingChannels: 'dual',
        recordingTrack: 'both',
        recordingStatusCallback: `${base}/twilio/ai-recording?callId=${id}`,
        recordingStatusCallbackMethod: 'POST',
        recordingStatusCallbackEvent: ['completed'],
        machineDetection: 'Enable',
        asyncAmd: 'true',
        asyncAmdStatusCallback: `${base}/twilio/ai-amd?callId=${id}`,
        asyncAmdStatusCallbackMethod: 'POST',
      });
      state.callSid = res.sid;
      state.twilio = { accountSid: tw.accountSid, authToken: tw.authToken };
      await persist();
      byCallSid.set(res.sid, { leadId, activityId: state.activityId });
      setTimeout(() => byCallSid.delete(res.sid), 60 * 60 * 1000).unref();
    } catch (err) {
      await finalize(state, { status: 'failed', error: err.message });
      throw new AiSetupError(err.message, 502);
    }

    await store.updateLead(leadId, { lastAiCallAt: new Date().toISOString(), lastAiCallStatus: 'initiated', lastCallBy: agent, $incrementCallCount: true });
    await saveActivity(state, { callSid: state.callSid });
    emit(state);
    return { callId: id, activityId: state.activityId, scriptName: script.name, voice: chosenVoice, ...(incoming ? { twiml: vr.toString() } : {}) };
  }

  async function hangup(state, reason) {
    if (state.hangingUp || !state.callSid || !state.twilio) return;
    state.hangingUp = reason;
    try {
      await accountApi.endCall({ ...state.twilio, callSid: state.callSid });
    } catch (err) {
      logger.error('[ai-call] hangup failed', err.message);
    }
    state.bridge?.close();
  }

  async function restore(callId) {
    if (calls.has(callId)) return calls.get(callId);
    const saved = await store.getAiSession?.(callId);
    if (!saved) return null;
    const state = { ...saved, twilio: profiles.active() };
    if (state.cartesia) state.cartesia.apiKey = await aiSettings.cartesiaApiKey();
    calls.set(callId, state);
    return state;
  }

  /** Twilio call status callback */
  async function onStatus(callId, body) {
    const state = await restore(callId);
    if (!state || state.finalized) return;
    const s = body.CallStatus === 'in-progress' ? 'answered' : body.CallStatus;
    if (!s) return;
    state.status = s;
    if (s === 'answered') state.answeredAt = Date.now();
    if (FINAL.has(s)) {
      state.duration = Number(body.CallDuration || 0);
      state.callEnded = true;
      // If the media stream is still open, the bridge's end will finalize.
      if (!state.bridge || state.bridgeEnded) await finalize(state, { status: s });
      else state.bridge.close();
      return;
    }
    await saveActivity(state, { status: s });
    await store.updateLead(state.leadId, { lastAiCallStatus: s });
    emit(state);
  }

  /** Twilio async answering-machine detection */
  async function onAmd(callId, body) {
    const state = await restore(callId);
    if (!state || state.finalized) return;
    const who = String(body.AnsweredBy || '');
    state.answeredBy = who;
    if (/^machine|^fax/.test(who)) {
      state.voicemail = true;
      await hangup(state, 'voicemail');
    }
  }

  /** Twilio recording callback — saves the recording id on the call's activity entry. */
  async function onRecording(callId, body) {
    const state = await restore(callId);
    const target = state ? { leadId: state.leadId, activityId: state.activityId } : byCallSid.get(String(body.CallSid || ''));
    if (!target || !body.RecordingSid) return;
    const patch = {
      recordingSid: String(body.RecordingSid),
      recordingDuration: Number(body.RecordingDuration || 0),
      recordingChannels: Number(body.RecordingChannels || 1),
      recordingAt: new Date().toISOString(),
    };
    await store.updateActivity(target.leadId, target.activityId, patch);
    realtime.emitActivity(target.leadId, await store.getActivity(target.leadId, target.activityId));
    await store.updateLead(target.leadId, { lastRecordingAt: patch.recordingAt }).catch(() => {});
  }

  /** Media stream WebSocket (wss://…/ai/stream) */
  const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });
  wss.on('connection', (ws) => {
    const authTimer = setTimeout(() => ws.close(), 10000);
    ws.on('message', function onFirst(raw) {
      void acceptFirst(raw).catch((err) => { logger.error('[ai-call] stream authentication failed', err.message); ws.close(); });
      async function acceptFirst(raw) {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }
      if (msg.event !== 'start') return;
      ws.off('message', onFirst);
      clearTimeout(authTimer);

      const params = msg.start?.customParameters || {};
      const state = await restore(params.callId);
      const tokenOk =
        state && typeof params.token === 'string' && params.token.length === state.token.length && crypto.timingSafeEqual(Buffer.from(params.token), Buffer.from(state.token));
      if (!tokenOk || state.bridge || state.finalized) {
        logger.error('[ai-call] rejected media stream');
        ws.close();
        return;
      }
      state.streamSid = msg.start.streamSid;
      state.token = crypto.randomBytes(24).toString('hex'); // single use
      await store.saveAiSession?.(state.id, { token: state.token });

      aiSettings.apiKey().then(async (apiKey) => {
        const settings = await aiSettings.get();
        state.bridge = runBridge({
          twilioWs: ws,
          streamSid: state.streamSid,
          apiKey,
          instructions: state.instructions,
          voice: state.voice,
          volume: state.volume,
          cartesia: state.cartesia,
          maxMs: settings.maxMinutes * 60 * 1000,
          autoHangup: settings.autoHangup,
          logger,
          requestHangup: (reason) => hangup(state, reason),
          isMonitored: () => realtime.listenerCount(state.id) > 0,
          onEvent: (ev) => {
            if (ev.type === 'audio') {
              realtime.emitAiAudio(state.id, ev.payload);
            } else if (ev.type === 'transcript') {
              realtime.io.to('admins').emit('ai:transcript', { callId: state.id, leadId: state.leadId, ...ev });
            } else if (ev.type === 'started') {
              state.status = 'in-conversation';
              emit(state);
            } else if (ev.type === 'optOut') {
              state.doNotCall = true;
              markDoNotCall(state).catch(() => {});
            } else if (ev.type === 'error') {
              state.aiError = ev.message;
            }
          },
          onEnd: async ({ reason, transcript, usage }) => {
            state.bridgeEnded = true;
            state.transcript = transcript;
            state.usage = usage;
            state.endReason = state.hangingUp || reason;
            // Give Twilio's final status callback a moment to arrive with the duration.
            setTimeout(() => finalize(state, { status: state.callEnded ? state.status : 'completed' }), state.callEnded ? 0 : 2500);
          },
        });
      }).catch((err) => { logger.error('[ai-call] bridge startup failed', err.message); ws.close(); finalize(state, { status: 'failed', error: err.message }).catch(() => {}); });
      }
    });
  });

  async function markDoNotCall(state) {
    if (state.dncSaved) return;
    state.dncSaved = true;
    await store.updateLead(state.leadId, { doNotCall: true, doNotCallAt: new Date().toISOString(), doNotCallSource: 'ai_call' });
    emit(state, { doNotCall: true });
  }

  function handleUpgrade(req, socket, head) {
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  }

  async function finalize(state, { status, error } = {}) {
    if (state.finalized) return;
    state.finalized = true;
    state.status = status || state.status;
    await store.saveAiSession?.(state.id, { finalized: true, status: state.status, token: '' });

    const transcript = state.transcript || [];
    const customerSpoke = transcript.some((t) => t.role === 'customer' && t.text.length > 1);
    const duration = state.duration || (state.answeredAt ? Math.round((Date.now() - state.answeredAt) / 1000) : 0);

    let outcome = '';
    if (state.voicemail) outcome = 'voicemail';
    else if (state.answeredAt && !customerSpoke) outcome = 'no_conversation';
    else if (customerSpoke) outcome = 'talked';

    const patch = {
      status: state.status,
      duration,
      endedAt: new Date().toISOString(),
      endReason: state.endReason || '',
      answeredBy: state.answeredBy || '',
      transcript,
      outcome,
      doNotCall: Boolean(state.doNotCall),
      ...(error || state.aiError ? { error: error || state.aiError } : {}),
    };

    // What was agreed: the appointment, whether every owner will be there, and opt-outs.
    let result = null;
    if (customerSpoke) {
      patch.resultStatus = 'pending';
      await saveActivity(state, patch).catch(() => {});
      emit(state, { working: true });
      try {
        const settings = await aiSettings.get();
        result = await extractCallResult({
          key: await aiSettings.apiKey(),
          model: settings.summaryModel,
          transcript,
          slots: state.slots || [],
          nowText: miamiNow(),
        });
      } catch (err) {
        logger.error('[ai-call] call result failed', err.message);
        patch.resultError = err.message;
      }
    }

    if (result?.doNotCall) state.doNotCall = true;
    if (state.doNotCall) {
      outcome = 'do_not_call';
      await markDoNotCall(state).catch(() => {});
    }

    // Book the agreed time on the calendar.
    if (result && result.appointmentSlot > 0 && !state.doNotCall) {
      const slot = (state.slots || [])[result.appointmentSlot - 1];
      if (slot) {
        try {
          const appointment = await calendar.book({
            leadId: state.leadId,
            start: slot.start,
            source: 'ai',
            agent: state.agent,
            allOwnersConfirmed: result.allOwnersConfirmed,
            notes: result.notes,
          });
          patch.appointmentId = appointment.id;
          patch.appointmentAt = appointment.start;
          patch.allOwnersConfirmed = Boolean(result.allOwnersConfirmed);
          outcome = 'appointment';
        } catch (err) {
          logger.error('[ai-call] booking failed', err.message);
          patch.appointmentError = `${slot.label}: ${err.message}`;
          patch.appointmentWanted = slot.start;
          outcome = 'appointment_failed';
        }
      }
    }
    if (result?.notes) patch.notes = result.notes;
    patch.outcome = outcome;
    patch.doNotCall = Boolean(state.doNotCall);
    patch.resultStatus = result ? 'done' : patch.resultStatus === 'pending' ? 'failed' : '';
    state.transcript = null;

    await saveActivity(state, patch).catch((err) => logger.error('[ai-call] save failed', err.message));

    const leadPatch = { lastAiCallStatus: state.status, lastAiOutcome: outcome };
    const lead = await store.getLead(state.leadId).catch(() => null);
    if (outcome === 'appointment' && lead?.status !== 'won') leadPatch.status = 'appointment';
    else if (customerSpoke && lead?.status === 'new') leadPatch.status = 'contacted';
    await store.updateLead(state.leadId, leadPatch).catch(() => {});

    emit(state, { outcome, finalized: true });
    // Forget the call after a while (tokens and credentials only live in memory)
    setTimeout(() => calls.delete(state.id), 10 * 60 * 1000).unref();
  }

  return {
    start,
    onStatus,
    onAmd,
    onRecording,
    recordingCreds: (leadId, activityId) => {
      const state = [...calls.values()].find((c) => c.leadId === leadId && c.activityId === activityId);
      return state?.twilio || profiles.active();
    },
    handleUpgrade,
    async hangupById(callId) {
      const state = await restore(callId);
      if (!state || state.finalized) return false;
      await hangup(state, 'agent_hangup');
      return true;
    },
    activeCalls: () =>
      [...calls.values()].filter((c) => !c.finalized).map((c) => ({ callId: c.id, leadId: c.leadId, status: c.status, agent: c.agent, scriptName: c.scriptName })),
    close() {
      for (const state of calls.values()) state.bridge?.close();
      wss.close();
    },
  };
}
