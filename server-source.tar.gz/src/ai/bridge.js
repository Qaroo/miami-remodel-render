import { LIVE_MODEL, OPT_OUT_RE, openLiveSocket } from './openai.js';
import { openCartesiaTts } from './cartesia.js';

/**
 * Relays one phone call between Twilio Media Streams and GPT-Live.
 *
 *   Twilio  ──μ-law 8kHz──▶  session.input_audio.append  ──▶ GPT-Live
 *   Twilio  ◀──20ms frames──  paced queue  ◀── session.output_audio.delta
 *
 * Both sides use G.711 μ-law 8 kHz, so audio is passed through without conversion.
 * Output audio is paced in real time, so when the caller starts talking over the
 * assistant we can drop what hasn't been played yet (Twilio "clear").
 */

const FRAME_BYTES = 160; // 20 ms of 8 kHz μ-law
const FRAME_MS = 20;

// μ-law byte → linear amplitude (0..32124), for a simple talk-over detector
const MU_LAW_ABS = new Int16Array(256).map((_, i) => {
  const u = ~i & 0xff;
  const exponent = (u >> 4) & 0x07;
  const mantissa = u & 0x0f;
  return ((mantissa << 3) + 0x84) << exponent;
});

// G.711 μ-law ⇄ 16-bit PCM, for the volume control
const MU_DECODE = new Int16Array(256).map((_, i) => {
  const u = ~i & 0xff;
  const sign = u & 0x80;
  const exponent = (u >> 4) & 0x07;
  const mantissa = u & 0x0f;
  const sample = (((mantissa << 3) + 0x84) << exponent) - 0x84;
  return sign ? -sample : sample;
});

function muEncode(sample) {
  const BIAS = 0x84;
  const CLIP = 32635;
  let sign = 0;
  if (sample < 0) {
    sample = -sample;
    sign = 0x80;
  }
  if (sample > CLIP) sample = CLIP;
  sample += BIAS;
  let exponent = 7;
  for (let mask = 0x4000; (sample & mask) === 0 && exponent > 0; mask >>= 1) exponent--;
  const mantissa = (sample >> (exponent + 3)) & 0x0f;
  return ~(sign | (exponent << 4) | mantissa) & 0xff;
}

/** Scale μ-law audio by `gain` (0.5–2). Uses a 256-entry lookup table per gain value. */
const gainTables = new Map();
export function applyGain(bytes, gain) {
  if (!gain || Math.abs(gain - 1) < 0.01) return bytes;
  let table = gainTables.get(gain);
  if (!table) {
    table = new Uint8Array(256).map((_, i) => muEncode(Math.max(-32768, Math.min(32767, Math.round(MU_DECODE[i] * gain)))));
    gainTables.set(gain, table);
  }
  const out = Buffer.allocUnsafe(bytes.length);
  for (let i = 0; i < bytes.length; i++) out[i] = table[bytes[i]];
  return out;
}

function frameEnergy(buf) {
  let sum = 0;
  for (let i = 0; i < buf.length; i++) sum += MU_LAW_ABS[buf[i]] - 132;
  return sum / buf.length;
}

export function runBridge({
  twilioWs,
  streamSid,
  apiKey,
  instructions,
  voice,
  volume = 1,
  cartesia = null,
  maxMs,
  autoHangup,
  isMonitored = () => false, // agents listening in?
  onEvent, // ({ type: 'started'|'optOut'|'transcript'|'audio'|'error', ... })
  onEnd, // ({ reason, transcript, usage }) — transcript is kept in memory only
  requestHangup,
  logger = console,
}) {
  const live = openLiveSocket(apiKey);
  const transcript = []; // { role: 'agent'|'customer', text } — memory only, never stored
  let optedOut = false;
  let current = null;
  let started = false;
  let ended = false;
  let usage = null;
  let activeResponseId = 'default';
  let cartesiaFinishTimer = null;

  const pushCartesiaTranscript = (delta) => {
    if (!cartesiaTts || !delta) return;
    cartesiaTts.push(delta, activeResponseId);
    clearTimeout(cartesiaFinishTimer);
    // Live transcript events intentionally have no "done" event. A short quiet
    // window marks the end of the utterance while preserving streaming playback.
    cartesiaFinishTimer = setTimeout(() => cartesiaTts.finish(activeResponseId), 140);
  };

  // ── Output pacing ──
  let queue = Buffer.alloc(0);
  let pacerStart = 0;
  let framesSent = 0;
  let lastOutAt = 0; // last audio received from GPT-Live
  let lastPlayedAt = 0; // last frame sent to the caller
  let lastInSpeechAt = Date.now();
  let loudFrames = 0;
  let goodbyeAt = 0;
  let lastOutFrame = null; // last 20 ms sent to the caller, for live listening
  let monitorFrames = [];

  const sendTwilio = (msg) => {
    if (twilioWs.readyState === 1) twilioWs.send(JSON.stringify(msg));
  };
  const sendLive = (msg) => {
    if (live.readyState === 1) live.send(JSON.stringify(msg));
  };

  const cartesiaTts = cartesia
    ? openCartesiaTts({
        ...cartesia,
        outputFormat: { container: 'raw', encoding: 'pcm_mulaw', sample_rate: 8000 },
        maxBufferDelayMs: 120,
        onAudio: (bytes) => {
          const audio = applyGain(bytes, volume);
          if (audio.length) {
            queue = queue.length ? Buffer.concat([queue, audio]) : audio;
            lastOutAt = Date.now();
          }
        },
        onError: (err) => {
          logger.error('[ai-call] Cartesia error', err.message);
          onEvent({ type: 'error', message: err.message || 'Cartesia TTS error' });
          if (!started) requestHangup('ai_error');
        },
      })
    : null;

  const pacer = setInterval(() => {
    if (!queue.length) {
      pacerStart = 0;
      return;
    }
    const now = Date.now();
    if (!pacerStart) {
      pacerStart = now;
      framesSent = 0;
    }
    // Send every frame that is due (keeps real-time pace even if the timer drifts)
    const due = Math.floor((now - pacerStart) / FRAME_MS) + 3 - framesSent; // ~60 ms lead
    for (let i = 0; i < due && queue.length; i++) {
      const frame = queue.subarray(0, FRAME_BYTES);
      queue = queue.subarray(frame.length);
      framesSent += 1;
      lastPlayedAt = now;
      lastOutFrame = frame;
      sendTwilio({ event: 'media', streamSid, media: { payload: Buffer.from(frame).toString('base64') } });
    }
  }, FRAME_MS);

  const flushPlayback = () => {
    if (!queue.length) return;
    queue = Buffer.alloc(0);
    pacerStart = 0;
    sendTwilio({ event: 'clear', streamSid });
  };

  // ── Transcript (kept with the call, and streamed live to the panel) ──
  let emitTimer = null;
  const emitCurrent = () => {
    emitTimer = null;
    if (current) onEvent({ type: 'transcript', index: transcript.length, role: current.role, text: current.text.trim(), final: false });
  };
  const pushDelta = (role, delta) => {
    if (!delta) return;
    if (!current || current.role !== role) {
      if (current?.text.trim()) {
        transcript.push({ role: current.role, text: current.text.trim(), at: current.at });
        onEvent({ type: 'transcript', index: transcript.length - 1, role: current.role, text: current.text.trim(), final: true });
      }
      current = { role, text: '', at: new Date().toISOString() };
    }
    current.text += delta;
    if (!emitTimer) emitTimer = setTimeout(emitCurrent, 300);
    if (role === 'customer' && !optedOut && OPT_OUT_RE.test(current.text)) {
      optedOut = true;
      onEvent({ type: 'optOut' });
    }
  };

  /** Mix what the caller says with what the assistant is saying, for live listening. */
  const monitorMix = (inbound) => {
    if (!isMonitored()) {
      if (monitorFrames.length) monitorFrames = [];
      return;
    }
    const out = lastOutFrame;
    const mixed = Buffer.allocUnsafe(inbound.length);
    for (let i = 0; i < inbound.length; i++) {
      const a = MU_DECODE[inbound[i]];
      const b = out && i < out.length ? MU_DECODE[out[i]] : 0;
      mixed[i] = muEncode(Math.max(-32768, Math.min(32767, a + b)));
    }
    monitorFrames.push(mixed);
    if (monitorFrames.length >= 10) {
      onEvent({ type: 'audio', payload: Buffer.concat(monitorFrames).toString('base64') });
      monitorFrames = [];
    }
  };

  // ── Timers ──
  const maxTimer = setTimeout(() => {
    logger.log('[ai-call] max duration reached');
    requestHangup('max_duration');
  }, maxMs);

  const watchdog = setInterval(() => {
    const now = Date.now();
    // Hang up after the assistant said goodbye and the audio finished playing
    if (goodbyeAt && !queue.length && now - lastOutAt > 1000 && now - lastPlayedAt > 1200) {
      goodbyeAt = 0;
      requestHangup('goodbye');
    }
    // Nobody talking for 30s
    if (started && now - Math.max(lastInSpeechAt, lastOutAt, lastPlayedAt) > 30000) requestHangup('silence');
  }, 500);

  // ── GPT-Live ──
  live.on('open', () => {
    sendLive({
      type: 'session.start',
      event_id: 'start',
      session: {
        model: LIVE_MODEL,
        instructions,
        audio: { format: { type: 'audio/pcmu', rate: 8000 }, output: { voice } },
        delegation: { type: 'client' },
      },
    });
  });

  live.on('message', (raw) => {
    let ev;
    try {
      ev = JSON.parse(raw.toString());
    } catch {
      return;
    }
    switch (ev.type) {
      case 'session.started':
        started = true;
        onEvent({ type: 'started' });
        break;
      case 'session.output_audio.delta': {
        if (cartesia) break; // Cartesia replaces GPT-Live's built-in speech.
        const bytes = applyGain(Buffer.from(ev.delta || '', 'base64'), volume);
        if (bytes.length) {
          queue = queue.length ? Buffer.concat([queue, bytes]) : bytes;
          lastOutAt = Date.now();
        }
        break;
      }
      case 'session.output_text.delta':
      case 'response.output_text.delta':
        activeResponseId = ev.response_id || activeResponseId;
        pushDelta('agent', ev.delta);
        pushCartesiaTranscript(ev.delta);
        if (autoHangup && current?.role === 'agent' && /\b(goodbye)\b|להתראות/i.test(current.text)) goodbyeAt = goodbyeAt || Date.now();
        break;
      case 'session.output_text.done':
      case 'response.output_text.done':
        cartesiaTts?.finish(ev.response_id || activeResponseId);
        break;
      case 'session.output_transcript.delta':
        pushDelta('agent', ev.delta);
        pushCartesiaTranscript(ev.delta);
        if (autoHangup && current?.role === 'agent' && /\b(goodbye|adi[oó]s)\b/i.test(current.text)) goodbyeAt = goodbyeAt || Date.now();
        break;
      case 'session.input_transcript.delta':
        pushDelta('customer', ev.delta);
        lastInSpeechAt = Date.now();
        goodbyeAt = 0;
        // The caller is talking and the assistant has stopped generating → drop unplayed audio
        if (Date.now() - lastOutAt > 250) {
          flushPlayback();
          clearTimeout(cartesiaFinishTimer);
          cartesiaTts?.cancel();
        }
        break;
      case 'session.delegation.created':
        // No backend tools on phone calls — tell the model to carry on from the script.
        sendLive({
          type: 'session.thinking.append',
          delegation_id: ev.delegation?.id,
          content: 'No backend tools are available on this call. Continue using the call script and the lead details you already have. If you cannot answer, offer that a project specialist will follow up.',
        });
        break;
      case 'session.closed':
        usage = ev.usage || null;
        live.close();
        break;
      case 'error':
        logger.error('[ai-call] GPT-Live error', ev.error?.message || ev);
        onEvent({ type: 'error', message: ev.error?.message || 'GPT-Live error' });
        if (!started) requestHangup('ai_error');
        break;
      default:
        break;
    }
  });

  live.on('unexpected-response', (req, res) => {
    logger.error(`[ai-call] GPT-Live refused the connection (${res.statusCode})`);
    onEvent({ type: 'error', message: `OpenAI refused the connection (${res.statusCode})` });
    requestHangup('ai_error');
  });
  live.on('error', (err) => logger.error('[ai-call] GPT-Live socket error', err.message));
  live.on('close', () => finish('ai_closed'));

  // ── Twilio ──
  twilioWs.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (msg.event === 'media' && msg.media?.payload && (!msg.media.track || msg.media.track === 'inbound')) {
      if (started) sendLive({ type: 'session.input_audio.append', audio: msg.media.payload });
      const inbound = Buffer.from(msg.media.payload, 'base64');
      monitorMix(inbound);
      lastOutFrame = null;
      // Talk-over detection: ~300 ms of loud audio while the assistant is silent-generating
      const energy = frameEnergy(inbound);
      loudFrames = energy > 900 ? loudFrames + 1 : 0;
      if (loudFrames >= 15) {
        lastInSpeechAt = Date.now();
        if (Date.now() - lastOutAt > 250) {
          flushPlayback();
          cartesiaTts?.cancel();
        }
      }
    } else if (msg.event === 'stop') {
      closeLive();
    }
  });
  twilioWs.on('close', () => closeLive());

  let closing = false;
  function closeLive() {
    if (closing) return;
    closing = true;
    if (live.readyState === 1) {
      sendLive({ type: 'session.close' });
      setTimeout(() => live.terminate(), 5000).unref();
    } else if (live.readyState === 0) {
      live.terminate();
    } else {
      finish('twilio_closed');
    }
    cartesiaTts?.close();
  }

  function finish(reason) {
    if (ended) return;
    ended = true;
    clearInterval(pacer);
    clearInterval(watchdog);
    clearTimeout(maxTimer);
    clearTimeout(emitTimer);
    clearTimeout(cartesiaFinishTimer);
    cartesiaTts?.close();
    if (current?.text.trim()) transcript.push({ role: current.role, text: current.text.trim(), at: current.at });
    if (twilioWs.readyState === 1) twilioWs.close();
    onEnd({ reason, transcript, usage });
  }

  return { close: closeLive };
}
