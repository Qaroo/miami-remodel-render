import WebSocket from 'ws';

/** OpenAI endpoints used by AI calls. OPENAI_BASE_URL is for local tests only. */
const BASE = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '');
export const LIVE_MODEL = 'gpt-live-1';

export class OpenAIError extends Error {
  constructor(message, status = 502) {
    super(message);
    this.status = status;
  }
}

async function call(path, { key, method = 'GET', body, timeoutMs = 20000 }) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      headers: { Authorization: `Bearer ${key}`, ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: ctrl.signal,
    });
  } catch (err) {
    throw new OpenAIError(err.name === 'AbortError' ? 'OpenAI did not respond in time.' : 'The server could not reach OpenAI.');
  } finally {
    clearTimeout(t);
  }
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* empty */
  }
  if (!res.ok) {
    const msg = data?.error?.message || `OpenAI error ${res.status}`;
    if (res.status === 401) throw new OpenAIError('OpenAI rejected the API key.', 400);
    // Preserve request/configuration errors so the Lead Desk shows the useful
    // OpenAI message instead of disguising every upstream rejection as a 502.
    if ([400, 403, 404, 422, 429].includes(res.status)) throw new OpenAIError(msg, res.status === 429 ? 429 : 400);
    throw new OpenAIError(msg, 502);
  }
  return data;
}

/** Check the key and that the account can use GPT-Live. */
export async function verifyKey(key) {
  try {
    await call(`/models/${LIVE_MODEL}`, { key, timeoutMs: 12000 });
    return { ok: true };
  } catch (err) {
    if (err.status === 502 && /not found|does not exist/i.test(err.message)) {
      throw new OpenAIError('The key works, but this OpenAI project does not have access to gpt-live-1 yet.', 400);
    }
    throw err;
  }
}

/** Browser test: create a GPT-Live session over WebRTC from the browser's SDP offer. */
export async function createWebrtcSession({ key, session, sdp }) {
  const data = await call('/live/sessions', { key, method: 'POST', body: { session, transport: { type: 'webrtc', sdp } } });
  const answer = data?.transport?.sdp;
  if (!answer) throw new OpenAIError('OpenAI did not return a WebRTC answer.');
  return { id: data.id || data.session?.id || '', sdp: answer };
}

/** Phone calls: open a GPT-Live WebSocket (server-side audio). */
export function openLiveSocket(key) {
  const url = `${BASE.replace(/^http/, 'ws')}/live/sessions`;
  return new WebSocket(url, { headers: { Authorization: `Bearer ${key}` } });
}

const RESULT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['doNotCall', 'appointmentSlot', 'allOwnersConfirmed', 'notes'],
  properties: {
    doNotCall: {
      type: 'boolean',
      description: 'True if the person asked not to be called again, asked to be removed, or said they never asked to be contacted.',
    },
    appointmentSlot: {
      type: 'integer',
      description: 'The number of the offered time the person agreed to (1-based, from the list given). 0 if no appointment was agreed.',
    },
    allOwnersConfirmed: {
      type: 'boolean',
      description: 'True only if the person confirmed that everyone who owns the home will be at the appointment.',
    },
    notes: { type: 'string', description: 'One or two short lines for the specialist: what the job is and anything to know. Empty string if nothing.' },
  },
};

/** Fast check on phrases like "stop calling me" / "no me llamen" (runs live during the call). */
export const OPT_OUT_RE =
  /\b(do not|don't|dont|stop|quit|never)\s+(call|calling|contact|contacting)\b|\bremove (me|my (number|name))\b|\b(take|put) me (off|on)\b.*\blist\b|\bdo[- ]not[- ]call\b|\bno (me|nos) (llam|vuelv)|\bdeje(n)? de llamar|\bno llamen\b|\bnever (asked|signed up|requested)\b/i;

const readJson = (data) => {
  const text =
    data.output_text ||
    (data.output || [])
      .flatMap((o) => o.content || [])
      .filter((c) => c.type === 'output_text')
      .map((c) => c.text)
      .join('');
  try {
    return JSON.parse(text);
  } catch {
    throw new OpenAIError('Could not read the call result.');
  }
};

/**
 * After a call: which offered time was agreed, whether every owner will be there,
 * and whether the person opted out.
 */
export async function extractCallResult({ key, model, transcript, slots = [], nowText }) {
  const lines = transcript.map((t) => `${t.role === 'agent' ? 'Assistant' : 'Customer'}: ${t.text}`).join('\n');
  const optOutHint = OPT_OUT_RE.test(transcript.filter((t) => t.role === 'customer').map((t) => t.text).join(' '));
  if (!lines.trim()) return { doNotCall: false, appointmentSlot: 0, allOwnersConfirmed: false, notes: '' };
  const offered = slots.length ? slots.map((s, i) => `${i + 1}. ${s.label}`).join('\n') : '(no times were offered)';
  const data = await call('/responses', {
    key,
    method: 'POST',
    timeoutMs: 45000,
    body: {
      model,
      store: false,
      input: [
        {
          role: 'system',
          content:
            'You read a phone call transcript between a home-improvement company assistant and a homeowner. Report only what was actually agreed. If the person did not clearly agree to one of the offered times, answer 0.',
        },
        { role: 'user', content: `Current Miami time: ${nowText}\n\nTimes that were offered:\n${offered}\n\nTranscript:\n${lines}` },
      ],
      text: { format: { type: 'json_schema', name: 'call_result', schema: RESULT_SCHEMA, strict: true } },
    },
  });
  const res = readJson(data);
  return {
    doNotCall: Boolean(res.doNotCall) || optOutHint,
    appointmentSlot: Number(res.appointmentSlot) || 0,
    allOwnersConfirmed: Boolean(res.allOwnersConfirmed),
    notes: String(res.notes || '').slice(0, 1000),
  };
}

/** Recording audio from Twilio, streamed through our server so it stays private. */
export async function fetchRecording({ accountSid, authToken, recordingSid, range }) {
  const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Recordings/${recordingSid}.mp3`;
  const auth = Buffer.from(`${accountSid}:${authToken}`).toString('base64');
  return fetch(url, { headers: { Authorization: `Basic ${auth}`, ...(range ? { Range: range } : {}) } });
}
