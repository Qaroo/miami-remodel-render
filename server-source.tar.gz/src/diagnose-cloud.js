import { validateConfig } from './config.js';
import { createFirestoreStore } from './store/firestoreStore.js';
import { createTwilioProfiles } from './twilio/profiles.js';
import { createAiSettings } from './ai/settings.js';
import { accountApi } from './twilio/accountApi.js';
validateConfig();
const store = createFirestoreStore();
const profiles = createTwilioProfiles({ store });
await profiles.init();
const ai = createAiSettings({ store });
const settings = await ai.get();
console.log(JSON.stringify({ twilio: profiles.status(), aiKeyAvailable: Boolean(await ai.apiKey()), ttsProvider: settings.ttsProvider, businessPhoneConfigured: Boolean(settings.businessPhone) }));
const p = profiles.active();
if (p) {
 const messages = await accountApi.listMessages({ accountSid: p.accountSid, authToken: p.authToken, limit: 30 });
 console.log(JSON.stringify({ recentSms: messages.map(m => ({ date: m.dateCreated, destinationPrefix: String(m.to).slice(0, 4), status: m.status, errorCode: m.errorCode, errorMessage: m.errorMessage })) }));
 const account = await accountApi.inspectAccount({ accountSid: p.accountSid, authToken: p.authToken });
 console.log(JSON.stringify({ accountType: account.accountType, accountStatus: account.accountStatus, senderOwned: account.numbers.some(n => n.phoneNumber === p.callerId && n.kind === 'twilio') }));
}
process.exit(0);
