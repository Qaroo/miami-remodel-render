import crypto from 'node:crypto';
import { config } from './config.js';

/**
 * Encrypts Twilio secrets before they are stored in the database (AES-256-GCM).
 * The key is derived from SESSION_SECRET — if you change SESSION_SECRET, re-enter your Twilio profiles.
 */
const key = () => Buffer.from(crypto.hkdfSync('sha256', config.admin.sessionSecret, 'miami-remodel', 'twilio-profiles', 32));

export function seal(plain) {
  if (!plain) return '';
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const data = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  return `v1.${iv.toString('base64url')}.${cipher.getAuthTag().toString('base64url')}.${data.toString('base64url')}`;
}

/** Returns null when the value can't be decrypted (e.g. SESSION_SECRET changed). */
export function open(sealed) {
  if (!sealed) return '';
  try {
    const [v, iv, tag, data] = String(sealed).split('.');
    if (v !== 'v1') return null;
    const decipher = crypto.createDecipheriv('aes-256-gcm', key(), Buffer.from(iv, 'base64url'));
    decipher.setAuthTag(Buffer.from(tag, 'base64url'));
    return Buffer.concat([decipher.update(Buffer.from(data, 'base64url')), decipher.final()]).toString('utf8');
  } catch {
    return null;
  }
}

export const mask = (value = '', keep = 4) => (value ? `${'•'.repeat(6)}${String(value).slice(-keep)}` : '');
