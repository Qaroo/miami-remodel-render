import crypto from 'node:crypto';
import twilio from 'twilio';
import { config } from '../config.js';

/**
 * Thin wrapper around the Twilio REST API calls Lead Desk needs.
 * Set TWILIO_FAKE_API=1 to use an in-memory fake (local tests only).
 */
const FRIENDLY_NAME = 'Miami Remodel Lead Desk';

export class TwilioSetupError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

function explain(err) {
  if (err instanceof TwilioSetupError) return err;
  const code = err?.code;
  if (code === 20003 || err?.status === 401) return new TwilioSetupError('Twilio rejected these credentials. Check the Account SID and Auth Token.');
  if (code === 21408 || /Permission to send an SMS has not been enabled for the region/i.test(err?.message || '')) {
    return new TwilioSetupError(
      'Twilio has SMS sending disabled for this destination. In Twilio Console, open Messaging → Settings → Geo Permissions, enable United States, save, and try again.',
      400
    );
  }
  if (code === 20404 || err?.status === 404) return new TwilioSetupError('Twilio could not find that resource. Check the SIDs you entered.');
  if (err?.code === 'ENOTFOUND' || err?.code === 'ECONNREFUSED' || err?.code === 'ETIMEDOUT') {
    return new TwilioSetupError('The server could not reach Twilio. Check your internet connection.', 502);
  }
  return new TwilioSetupError(err?.message ? `Twilio: ${err.message}` : 'Twilio request failed.', 502);
}

async function wrap(fn) {
  try {
    return await fn();
  } catch (err) {
    throw explain(err);
  }
}

function realApi() {
  const client = (accountSid, authToken) => twilio(accountSid, authToken, { autoRetry: true, maxRetries: 2 });

  return {
    async inspectAccount({ accountSid, authToken }) {
      return wrap(async () => {
        const c = client(accountSid, authToken);
        const [account, numbers, verified] = await Promise.all([
          c.api.v2010.accounts(accountSid).fetch(),
          c.incomingPhoneNumbers.list({ limit: 200 }),
          c.outgoingCallerIds.list({ limit: 50 }).catch(() => []),
        ]);
        return {
          accountName: account.friendlyName,
          accountType: account.type, // "Trial" | "Full"
          accountStatus: account.status,
          numbers: [
            ...numbers
              .filter((n) => n.capabilities?.voice !== false)
              .map((n) => ({ phoneNumber: n.phoneNumber, label: n.friendlyName, kind: 'twilio' })),
            ...verified.map((v) => ({ phoneNumber: v.phoneNumber, label: v.friendlyName, kind: 'verified' })),
          ],
        };
      });
    },

    async createApiKey({ accountSid, authToken }) {
      return wrap(async () => {
        const key = await client(accountSid, authToken).newKeys.create({ friendlyName: FRIENDLY_NAME });
        return { sid: key.sid, secret: key.secret };
      });
    },

    async createTwimlApp({ accountSid, authToken, voiceUrl }) {
      return wrap(async () => {
        const app = await client(accountSid, authToken).applications.create({
          friendlyName: FRIENDLY_NAME,
          voiceMethod: 'POST',
          ...(voiceUrl ? { voiceUrl } : {}),
        });
        return { sid: app.sid };
      });
    },

    async updateVoiceUrl({ accountSid, authToken, twimlAppSid, voiceUrl }) {
      return wrap(() => client(accountSid, authToken).applications(twimlAppSid).update({ voiceUrl, voiceMethod: 'POST' }));
    },

    async updateSmsUrl({ accountSid, authToken, callerId, smsUrl, voiceUrl }) {
      return wrap(async () => {
        const c = client(accountSid, authToken);
        const numbers = await c.incomingPhoneNumbers.list({ phoneNumber: callerId, limit: 10 });
        const number = numbers.find((n) => n.phoneNumber === callerId);
        if (!number) throw new TwilioSetupError('The selected caller ID is not a Twilio phone number, so it cannot receive SMS in Lead Desk.');
        await c.incomingPhoneNumbers(number.sid).update({ smsUrl, smsMethod: 'POST', ...(voiceUrl ? { voiceUrl, voiceMethod: 'POST' } : {}) });
        return { sid: number.sid, smsUrl };
      });
    },

    async sendMessage({ accountSid, authToken, ...params }) {
      return wrap(async () => {
        const message = await twilio(accountSid, authToken, { autoRetry: false }).messages.create(params);
        return message;
      });
    },

    async listMessages({ accountSid, authToken, limit = 200 }) {
      return wrap(() => client(accountSid, authToken).messages.list({ limit }));
    },

    async checkResources({ accountSid, authToken, apiKeySid, twimlAppSid }) {
      return wrap(async () => {
        const c = client(accountSid, authToken);
        await Promise.all([c.keys(apiKeySid).fetch(), c.applications(twimlAppSid).fetch()]);
      });
    },

    /** Outbound call with inline TwiML (AI calls). */
    async placeCall({ accountSid, authToken, ...params }) {
      return wrap(async () => {
        const callRes = await twilio(accountSid, authToken, { autoRetry: false }).calls.create(params);
        return { sid: callRes.sid };
      });
    },

    async endCall({ accountSid, authToken, callSid }) {
      return wrap(() => client(accountSid, authToken).calls(callSid).update({ status: 'completed' }));
    },

    async removeResources({ accountSid, authToken, apiKeySid, twimlAppSid }) {
      const c = client(accountSid, authToken);
      await Promise.allSettled([apiKeySid && c.keys(apiKeySid).remove(), twimlAppSid && c.applications(twimlAppSid).remove()]);
    },
  };
}

/** In-memory fake for tests (TWILIO_FAKE_API=1). Auth token "0000…" is treated as wrong. */
function fakeApi() {
  const apps = new Map();
  const sid = (prefix) => prefix + crypto.randomBytes(16).toString('hex');
  const check = ({ authToken }) => {
    if (/^0+$/.test(authToken)) throw new TwilioSetupError('Twilio rejected these credentials. Check the Account SID and Auth Token.');
  };
  return {
    fake: true,
    apps,
    async inspectAccount(creds) {
      check(creds);
      return {
        accountName: 'Test account',
        accountType: 'Full',
        accountStatus: 'active',
        numbers: [
          { phoneNumber: '+13055550199', label: '(305) 555-0199', kind: 'twilio' },
          { phoneNumber: '+17865550123', label: '(786) 555-0123', kind: 'twilio' },
        ],
      };
    },
    async createApiKey(creds) {
      check(creds);
      return { sid: sid('SK'), secret: crypto.randomBytes(16).toString('hex') };
    },
    async createTwimlApp({ voiceUrl, ...creds }) {
      check(creds);
      const s = sid('AP');
      apps.set(s, { voiceUrl });
      return { sid: s };
    },
    async updateVoiceUrl({ twimlAppSid, voiceUrl, ...creds }) {
      check(creds);
      apps.set(twimlAppSid, { voiceUrl });
    },
    async updateSmsUrl({ callerId, smsUrl, ...creds }) {
      check(creds);
      this.smsUrl = { callerId, smsUrl };
      return this.smsUrl;
    },
    messages: [],
    async sendMessage({ accountSid, authToken, ...params }) {
      check({ authToken });
      const message = { sid: sid('SM'), status: 'queued', direction: 'outbound-api', dateCreated: new Date(), ...params };
      this.messages.push(message);
      return message;
    },
    async listMessages(creds) {
      check(creds);
      return [...this.messages];
    },
    async checkResources(creds) {
      check(creds);
    },
    async removeResources({ twimlAppSid }) {
      apps.delete(twimlAppSid);
    },
    calls: [],
    async placeCall({ accountSid, authToken, ...params }) {
      check({ authToken });
      const callSid = sid('CA');
      this.calls.push({ sid: callSid, ...params });
      if (process.env.TWILIO_FAKE_CALLS_FILE) {
        const fs = await import('node:fs');
        fs.appendFileSync(process.env.TWILIO_FAKE_CALLS_FILE, JSON.stringify({ sid: callSid, ...params }) + '\n');
      }
      return { sid: callSid };
    },
    async endCall({ callSid }) {
      this.ended = [...(this.ended || []), callSid];
      if (process.env.TWILIO_FAKE_CALLS_FILE) {
        const fs = await import('node:fs');
        fs.appendFileSync(process.env.TWILIO_FAKE_CALLS_FILE, JSON.stringify({ ended: callSid }) + '\n');
      }
    },
  };
}

export const accountApi = process.env.TWILIO_FAKE_API === '1' && !config.isProd ? fakeApi() : realApi();
