import { EventEmitter } from 'node:events';
import { config, envTwilio } from '../config.js';
import { runtime } from '../runtime.js';
import { mask, open, seal } from '../secrets.js';
import { TwilioSetupError, accountApi } from './accountApi.js';

const RE = {
  accountSid: /^AC[0-9a-f]{32}$/i,
  authToken: /^[0-9a-z]{32}$/i,
  apiKeySid: /^SK[0-9a-f]{32}$/i,
  twimlAppSid: /^AP[0-9a-f]{32}$/i,
  callerId: /^\+[1-9]\d{7,14}$/,
};

const clean = (v, max = 200) => String(v ?? '').trim().slice(0, max);
const voiceUrlFor = (base) => (base ? `${base}/twilio/voice` : '');
const smsUrlFor = (base) => (base ? `${base}/twilio/sms/incoming` : '');

function requireFields(input, fields) {
  const messages = {
    name: 'Give this profile a name.',
    accountSid: 'Account SID should start with AC and be 34 characters.',
    authToken: 'Auth Token should be 32 characters.',
    apiKeySid: 'API Key SID should start with SK and be 34 characters.',
    apiKeySecret: 'Enter the API Key Secret.',
    twimlAppSid: 'TwiML App SID should start with AP and be 34 characters.',
    callerId: 'Choose the number calls will come from (format +13055550123).',
  };
  for (const f of fields) {
    const v = input[f];
    const ok = f === 'name' ? v.length >= 2 : f === 'apiKeySecret' ? v.length >= 16 : RE[f].test(v);
    if (!ok) throw new TwilioSetupError(messages[f]);
  }
}

/**
 * Twilio profiles: saved Twilio accounts, one active for the whole team.
 * Secrets are encrypted at rest and never sent back to the browser.
 */
export function createTwilioProfiles({ store, logger = console }) {
  const events = new EventEmitter();
  let active = null; // decrypted active profile (or .env fallback)
  let activeId = null;

  function decrypt(doc) {
    if (!doc) return null;
    const authToken = open(doc.authTokenEnc);
    const apiKeySecret = open(doc.apiKeySecretEnc);
    const broken = authToken === null || apiKeySecret === null;
    return { ...doc, authToken: authToken || '', apiKeySecret: apiKeySecret || '', broken };
  }

  function publicView(doc, activeProfileId) {
    const p = decrypt(doc);
    return {
      id: p.id,
      name: p.name,
      mode: p.mode,
      accountSid: p.accountSid,
      accountName: p.accountName || '',
      accountType: p.accountType || '',
      callerId: p.callerId,
      apiKeySid: mask(p.apiKeySid, 6),
      twimlAppSid: p.twimlAppSid,
      authToken: mask(p.authToken),
      voiceUrl: p.voiceUrl || '',
      smsUrl: p.smsUrl || '',
      lastSyncAt: p.lastSyncAt || null,
      lastSyncError: p.lastSyncError || '',
      createdAt: p.createdAt || null,
      createdBy: p.createdBy || '',
      active: p.id === activeProfileId,
      broken: p.broken,
    };
  }

  async function refresh() {
    const settings = await store.getSettings('twilio');
    activeId = settings.activeProfileId || null;
    const doc = activeId ? await store.getProfile(activeId) : null;
    const p = decrypt(doc);
    active = p && !p.broken ? p : envTwilio();
    events.emit('changed', status());
    return active;
  }

  function status() {
    if (active) return { mode: 'live', profileId: active.id, profileName: active.name, callerId: active.callerId };
    return { mode: config.mock ? 'mock' : 'off' };
  }

  /** Point the active profile's TwiML App at the current public URL. */
  async function syncVoiceUrl() {
    const p = active;
    if (!p || p.id === 'env') return { skipped: true };
    const voiceUrl = voiceUrlFor(runtime.publicUrl);
    if (!voiceUrl) return { skipped: true };
    try {
      await accountApi.updateVoiceUrl({ accountSid: p.accountSid, authToken: p.authToken, twimlAppSid: p.twimlAppSid, voiceUrl });
      const smsUrl = smsUrlFor(runtime.publicUrl);
      let smsSyncError = '';
      if (smsUrl) {
        try {
          await accountApi.updateSmsUrl({ accountSid: p.accountSid, authToken: p.authToken, callerId: p.callerId, smsUrl, voiceUrl: `${runtime.publicUrl}/twilio/incoming` });
        } catch (err) {
          smsSyncError = err.message;
          logger.error(`  ✖ Could not update Twilio SMS URL: ${err.message}`);
        }
      }
      await store.updateProfile(p.id, { voiceUrl, smsUrl: smsSyncError ? '' : smsUrl, smsSyncError, lastSyncAt: new Date().toISOString(), lastSyncError: '' });
      active = { ...active, voiceUrl, smsUrl: smsSyncError ? '' : smsUrl, smsSyncError };
      logger.log(`  ✔ Twilio "${p.name}" now sends calls to ${voiceUrl}`);
      return { voiceUrl };
    } catch (err) {
      await store.updateProfile(p.id, { lastSyncError: err.message, lastSyncAt: new Date().toISOString() }).catch(() => {});
      logger.error(`  ✖ Could not update Twilio voice URL: ${err.message}`);
      return { error: err.message };
    }
  }

  return {
    init: async () => {
      await refresh();
      return status();
    },
    status,
    /** The live credentials for calls, or null. */
    active: () => active,
    onChange(fn) {
      events.on('changed', fn);
      return () => events.off('changed', fn);
    },
    syncVoiceUrl,

    async list() {
      const docs = await store.listProfiles();
      return {
        mode: status().mode,
        activeProfileId: activeId,
        usingEnv: active?.id === 'env',
        publicUrl: runtime.publicUrl,
        voiceUrl: voiceUrlFor(runtime.publicUrl),
        smsUrl: smsUrlFor(runtime.publicUrl),
        profiles: docs.map((d) => publicView(d, activeId)),
      };
    },

    /** Step 1 of the simple setup: check credentials and list the account's numbers. */
    async lookup(body) {
      const input = { accountSid: clean(body.accountSid, 40), authToken: clean(body.authToken, 40) };
      requireFields(input, ['accountSid', 'authToken']);
      return accountApi.inspectAccount(input);
    },

    async create(body, agent) {
      const mode = body.mode === 'manual' ? 'manual' : 'auto';
      const input = {
        name: clean(body.name, 60),
        accountSid: clean(body.accountSid, 40),
        authToken: clean(body.authToken, 40),
        callerId: clean(body.callerId, 20).replace(/[^\d+]/g, ''),
        apiKeySid: clean(body.apiKeySid, 40),
        apiKeySecret: clean(body.apiKeySecret, 100),
        twimlAppSid: clean(body.twimlAppSid, 40),
      };
      const creds = { accountSid: input.accountSid, authToken: input.authToken };
      const voiceUrl = voiceUrlFor(runtime.publicUrl);
      let accountInfo = {};
      let autoCreated = { apiKey: false, twimlApp: false };

      if (mode === 'auto') {
        requireFields(input, ['name', 'accountSid', 'authToken', 'callerId']);
        accountInfo = await accountApi.inspectAccount(creds);
        const key = await accountApi.createApiKey(creds);
        let app;
        try {
          app = await accountApi.createTwimlApp({ ...creds, voiceUrl });
        } catch (err) {
          await accountApi.removeResources({ ...creds, apiKeySid: key.sid });
          throw err;
        }
        input.apiKeySid = key.sid;
        input.apiKeySecret = key.secret;
        input.twimlAppSid = app.sid;
        autoCreated = { apiKey: true, twimlApp: true };
      } else {
        requireFields(input, ['name', 'accountSid', 'authToken', 'apiKeySid', 'apiKeySecret', 'twimlAppSid', 'callerId']);
        accountInfo = await accountApi.inspectAccount(creds);
        await accountApi.checkResources({ ...creds, apiKeySid: input.apiKeySid, twimlAppSid: input.twimlAppSid });
      }

      const id = await store.createProfile({
        name: input.name,
        mode,
        accountSid: input.accountSid,
        accountName: accountInfo.accountName || '',
        accountType: accountInfo.accountType || '',
        callerId: input.callerId,
        apiKeySid: input.apiKeySid,
        twimlAppSid: input.twimlAppSid,
        authTokenEnc: seal(input.authToken),
        apiKeySecretEnc: seal(input.apiKeySecret),
        autoCreated,
        voiceUrl: mode === 'auto' ? voiceUrl : '',
        createdBy: agent,
      });

      const makeActive = body.makeActive !== false;
      if (makeActive) {
        await store.setSettings('twilio', { activeProfileId: id, changedBy: agent });
        await refresh();
        await syncVoiceUrl();
      }
      return { id, active: makeActive };
    },

    async activate(id, agent) {
      const doc = await store.getProfile(id);
      if (!doc) throw new TwilioSetupError('Profile not found.', 404);
      if (decrypt(doc).broken) throw new TwilioSetupError('This profile can no longer be decrypted (SESSION_SECRET changed). Delete it and add it again.');
      await store.setSettings('twilio', { activeProfileId: id, changedBy: agent });
      await refresh();
      return syncVoiceUrl();
    },

    async deactivate(agent) {
      await store.setSettings('twilio', { activeProfileId: null, changedBy: agent });
      await refresh();
    },

    async remove(id, agent) {
      const doc = await store.getProfile(id);
      if (!doc) throw new TwilioSetupError('Profile not found.', 404);
      const p = decrypt(doc);
      if (!p.broken && (p.autoCreated?.apiKey || p.autoCreated?.twimlApp)) {
        await accountApi.removeResources({
          accountSid: p.accountSid,
          authToken: p.authToken,
          apiKeySid: p.autoCreated.apiKey ? p.apiKeySid : '',
          twimlAppSid: p.autoCreated.twimlApp ? p.twimlAppSid : '',
        });
      }
      await store.deleteProfile(id);
      if (id === activeId) await store.setSettings('twilio', { activeProfileId: null, changedBy: agent });
      await refresh();
    },
  };
}
