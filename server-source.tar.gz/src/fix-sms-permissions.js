import twilio from 'twilio';
import { validateConfig } from './config.js';
import { createFirestoreStore } from './store/firestoreStore.js';
import { createTwilioProfiles } from './twilio/profiles.js';
validateConfig();
const store = createFirestoreStore();
const profiles = createTwilioProfiles({store});
await profiles.init();
const p = profiles.active();
if (!p) throw new Error('No active Twilio profile');
const c = twilio(p.accountSid, p.authToken);
try {
 const before = await c.accounts.v1.messagingGeopermissions.fetch({countryCode:'US'});
 console.log('US permissions:', JSON.stringify(before.permissions));
 if (process.argv.includes('--enable')) {
  const after = await c.accounts.v1.messagingGeopermissions.update({permissions:[{country_code:'US',type:'country',enabled:true}]});
  console.log('Result:',JSON.stringify(after.permissions));
 }
} catch(e) { console.log('Permission API unavailable:',e.code,e.message); }
process.exit(0);
