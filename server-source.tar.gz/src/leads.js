/** Shared lead constants + validation (mirrors firestore.rules). */

export const LEAD_STATUSES = ['new', 'contacted', 'qualified', 'appointment', 'won', 'lost'];

const str = (v, max) => typeof v === 'string' && v.length <= max;

export function validatePublicLead(body) {
  const errors = [];
  const b = body || {};
  if (!str(b.projectType, 60) || !b.projectType) errors.push('projectType');
  if (b.homeowner !== 'Yes') errors.push('homeowner');
  if (!str(b.county, 40) || !b.county) errors.push('county');
  if (typeof b.zipCode !== 'string' || !/^\d{5}$/.test(b.zipCode)) errors.push('zipCode');
  if (!str(b.timeline, 60)) errors.push('timeline');
  if (!str(b.paymentPreference, 60)) errors.push('paymentPreference');
  if (typeof b.financingInterest !== 'boolean') errors.push('financingInterest');
  if (!str(b.firstName, 80) || b.firstName.trim().length < 2) errors.push('firstName');
  if (!str(b.lastName, 80) || b.lastName.trim().length < 2) errors.push('lastName');
  if (typeof b.phone !== 'string' || !/^\+1\d{10}$/.test(b.phone)) errors.push('phone');
  if (!str(b.email, 200) || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(b.email)) errors.push('email');
  return errors;
}

const PUBLIC_FIELDS = [
  'projectType', 'homeowner', 'county', 'zipCode', 'timeline', 'paymentPreference', 'financingInterest',
  'firstName', 'lastName', 'phone', 'email',
  'utmSource', 'utmMedium', 'utmCampaign', 'utmContent', 'utmTerm', 'landingPage', 'meta', 'consent',
];

export function pickPublicLead(body) {
  const out = {};
  for (const k of PUBLIC_FIELDS) if (k in body) out[k] = body[k];
  for (const k of ['utmSource', 'utmMedium', 'utmCampaign', 'utmContent', 'utmTerm', 'landingPage']) {
    out[k] = typeof out[k] === 'string' ? out[k].slice(0, 500) : '';
  }
  if (out.meta && typeof out.meta !== 'object') delete out.meta;
  if (out.consent && typeof out.consent !== 'object') delete out.consent;
  return { ...out, status: 'new', source: 'website', callCount: 0 };
}

/** Is it currently inside allowed calling hours in the lead's time zone? */
export function callingWindow({ timeZone, start, end }, date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone, hour: 'numeric', minute: '2-digit', hour12: false }).formatToParts(date);
  const hour = Number(parts.find((p) => p.type === 'hour').value) % 24;
  const minute = Number(parts.find((p) => p.type === 'minute').value);
  const label = new Intl.DateTimeFormat('en-US', { timeZone, hour: 'numeric', minute: '2-digit' }).format(date);
  return { allowed: hour >= start && hour < end, hour, minute, label, timeZone, start, end };
}
