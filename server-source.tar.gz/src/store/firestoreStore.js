import { cert, initializeApp, getApps } from 'firebase-admin/app';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';
import { config } from '../config.js';
import { mergeSms } from '../sms.js';
import { toPlain } from './serialize.js';

/**
 * Firestore-backed store (production).
 * Collections:
 *   leads/{leadId}                 — written by the website (see firestore.rules)
 *   leads/{leadId}/activity/{id}   — notes, status changes, calls (server only)
 *   twilioProfiles/{id}            — Twilio accounts added in Lead Desk → Settings (secrets encrypted, server only)
 *   settings/twilio                — { activeProfileId } (server only)
 *   settings/ai, aiScripts/{id}    — AI call settings (OpenAI key encrypted) and scripts (server only)
 *   settings/calendar, appointments/{id} — in-house appointment calendar (server only)
 *   public/leadDesk                — { url, online } so the admin panel can find this server (public read)
 */
export function createFirestoreStore() {
  const app = getApps()[0] || initializeApp(
    config.firebase.serviceAccount
      ? { credential: cert(config.firebase.serviceAccount), projectId: config.firebase.projectId || undefined }
      : { projectId: config.firebase.projectId || process.env.GCLOUD_PROJECT || 'miamiremodel' }
  );
  const db = getFirestore(app);
  const leads = db.collection(config.firebase.leadsCollection);

  const profiles = db.collection('twilioProfiles');
  const leadFromDoc = (doc) => ({ id: doc.id, ...toPlain(doc.data()) });

  return {
    kind: 'firestore',
    db,
    async saveAiSession(id, data) { await db.collection('aiSessions').doc(id).set(data, { merge: true }); },
    async getAiSession(id) { const d = await db.collection('aiSessions').doc(id).get(); return d.exists ? d.data() : null; },

    watchLeads(limit, onChange, onError) {
      let first = true;
      return leads
        .orderBy('createdAt', 'desc')
        .limit(limit)
        .onSnapshot(
          (snap) => {
            // The first snapshot replays existing docs as "added" — clients already get those via leads:snapshot.
            if (first) {
              first = false;
              return;
            }
            snap.docChanges().forEach((change) => {
              onChange({ type: change.type, lead: leadFromDoc(change.doc) });
            });
          },
          (err) => onError?.(err)
        );
    },

    async listLeads(limit) {
      const snap = await leads.orderBy('createdAt', 'desc').limit(limit).get();
      return snap.docs.map(leadFromDoc);
    },

    async getLead(id) {
      const doc = await leads.doc(id).get();
      return doc.exists ? leadFromDoc(doc) : null;
    },

    async setPhoneOptOut(phone, patch) {
      const snap = await leads.where('phone', '==', phone).get();
      for (let offset = 0; offset < snap.docs.length; offset += 400) {
        const batch = db.batch();
        for (const doc of snap.docs.slice(offset, offset + 400)) batch.set(doc.ref, { ...patch, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
        await batch.commit();
      }
    },

    async phoneOptOut(phone, field) {
      const snap = await leads.where('phone', '==', phone).get();
      return snap.docs.some((doc) => doc.data()[field] === true);
    },

    async findLeadByPhone(phone) {
      const snap = await leads.where('phone', '==', phone).limit(1).get();
      return snap.empty ? null : leadFromDoc(snap.docs[0]);
    },

    async createLead(data) {
      const ref = await leads.add({ ...data, createdAt: FieldValue.serverTimestamp() });
      return ref.id;
    },

    async updateLead(id, patch) {
      const data = { ...patch, updatedAt: FieldValue.serverTimestamp() };
      if (patch.$incrementCallCount) {
        delete data.$incrementCallCount;
        data.callCount = FieldValue.increment(1);
      }
      await leads.doc(id).set(data, { merge: true });
    },

    async deleteLead(id) {
      const ref = leads.doc(id);
      const appointmentSnap = await db.collection('appointments').where('leadId', '==', id).get();
      const batch = db.batch();
      appointmentSnap.docs.forEach((doc) => batch.delete(doc.ref));
      if (!appointmentSnap.empty) await batch.commit();
      await db.recursiveDelete(ref);
    },

    async addActivity(leadId, entry) {
      const ref = await leads.doc(leadId).collection('activity').add({ ...entry, createdAt: FieldValue.serverTimestamp() });
      return ref.id;
    },

    async updateActivity(leadId, activityId, patch) {
      await leads
        .doc(leadId)
        .collection('activity')
        .doc(activityId)
        .set({ ...patch, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    },

    async getActivity(leadId, activityId) {
      const doc = await leads.doc(leadId).collection('activity').doc(activityId).get();
      return doc.exists ? { id: doc.id, ...toPlain(doc.data()) } : null;
    },

    async listActivity(leadId) {
      const snap = await leads.doc(leadId).collection('activity').orderBy('createdAt', 'desc').limit(200).get();
      return snap.docs.map((d) => ({ id: d.id, ...toPlain(d.data()) }));
    },

    // ── Appointments ──
    async listAppointments({ from, to }) {
      const snap = await db.collection('appointments').where('start', '>=', from).where('start', '<=', to).orderBy('start', 'asc').get();
      return snap.docs.map((d) => ({ id: d.id, ...toPlain(d.data()) }));
    },

    async listAppointmentsForLead(leadId) {
      const snap = await db.collection('appointments').where('leadId', '==', leadId).get();
      return snap.docs.map((d) => ({ id: d.id, ...toPlain(d.data()) })).sort((a, b) => b.start.localeCompare(a.start));
    },

    async getAppointment(id) {
      const doc = await db.collection('appointments').doc(id).get();
      return doc.exists ? { id: doc.id, ...toPlain(doc.data()) } : null;
    },

    async createAppointment(data) {
      const ref = await db.collection('appointments').add({ ...data, createdAt: FieldValue.serverTimestamp() });
      return ref.id;
    },

    async updateAppointment(id, patch) {
      await db.collection('appointments').doc(id).set({ ...patch, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    },

    // ── Twilio profiles + settings ──
    async listProfiles() {
      const snap = await profiles.orderBy('createdAt', 'asc').get();
      return snap.docs.map((d) => ({ id: d.id, ...toPlain(d.data()) }));
    },

    async getProfile(id) {
      const doc = await profiles.doc(id).get();
      return doc.exists ? { id: doc.id, ...toPlain(doc.data()) } : null;
    },

    async createProfile(data) {
      const ref = await profiles.add({ ...data, createdAt: FieldValue.serverTimestamp() });
      return ref.id;
    },

    async updateProfile(id, patch) {
      await profiles.doc(id).set({ ...patch, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    },

    async deleteProfile(id) {
      await profiles.doc(id).delete();
    },

    // ── AI call scripts ──
    async listScripts() {
      const snap = await db.collection('aiScripts').orderBy('createdAt', 'asc').get();
      return snap.docs.map((d) => ({ id: d.id, ...toPlain(d.data()) }));
    },

    async getScript(id) {
      const doc = await db.collection('aiScripts').doc(id).get();
      return doc.exists ? { id: doc.id, ...toPlain(doc.data()) } : null;
    },

    async createScript(data) {
      const ref = await db.collection('aiScripts').add({ ...data, createdAt: FieldValue.serverTimestamp() });
      return ref.id;
    },

    async updateScript(id, patch) {
      await db.collection('aiScripts').doc(id).set({ ...patch, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    },

    async deleteScript(id) {
      await db.collection('aiScripts').doc(id).delete();
    },

    async getSettings(name) {
      const doc = await db.collection('settings').doc(name).get();
      return doc.exists ? toPlain(doc.data()) : {};
    },

    async setSettings(name, patch) {
      await db.collection('settings').doc(name).set({ ...patch, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    },

    // ── SMS history (Twilio is synced into Firestore so messages survive restarts) ──
    async upsertSms(messageId, data) {
      const ref = db.collection('smsMessages').doc(messageId);
      await db.runTransaction(async (tx) => {
        const current = await tx.get(ref);
        tx.set(ref, { ...mergeSms(current.exists ? toPlain(current.data()) : {}, data), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
      });
      const doc = await ref.get();
      return { id: doc.id, ...toPlain(doc.data()) };
    },

    async getSms(messageId) {
      const doc = await db.collection('smsMessages').doc(messageId).get();
      return doc.exists ? { id: doc.id, ...toPlain(doc.data()) } : null;
    },

    async listSms({ leadId, limit = 300 } = {}) {
      let query = db.collection('smsMessages');
      if (leadId) query = query.where('leadId', '==', leadId);
      const snap = await query.limit(Math.min(Number(limit) || 300, 500)).get();
      return snap.docs
        .map((d) => ({ id: d.id, ...toPlain(d.data()) }))
        .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
    },


    async publishServer(data) {
      await db.collection('public').doc('leadDesk').set({ ...data, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    },
  };
}
