import crypto from 'node:crypto';

/**
 * In-memory store for MOCK_MODE=1 — lets you run the whole admin panel
 * locally without Firebase. Data resets when the server restarts.
 */
export function createMemoryStore({ seed = true } = {}) {
  const leads = new Map();
  const activity = new Map(); // leadId -> Map
  const watchers = new Set();
  const profiles = new Map();
  const settings = new Map();
  const scripts = new Map();
  const appointments = new Map();
  const smsMessages = new Map();
  const now = () => new Date().toISOString();
  const id = () => crypto.randomBytes(10).toString('hex');

  const emit = (type, lead) => watchers.forEach((w) => w({ type, lead: structuredClone(lead) }));

  const api = {
    kind: 'memory',

    watchLeads(limit, onChange) {
      watchers.add(onChange);
      return () => watchers.delete(onChange);
    },

    async listLeads(limit) {
      return [...leads.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit).map((l) => structuredClone(l));
    },

    async getLead(leadId) {
      return leads.has(leadId) ? structuredClone(leads.get(leadId)) : null;
    },

    async findLeadByPhone(phone) {
      return structuredClone([...leads.values()].find((lead) => lead.phone === phone) || null);
    },

    async createLead(data, createdAt = now()) {
      const lead = { id: id(), ...data, createdAt };
      leads.set(lead.id, lead);
      emit('added', lead);
      return lead.id;
    },

    async updateLead(leadId, patch) {
      const lead = leads.get(leadId);
      if (!lead) return;
      const next = { ...lead, ...patch, updatedAt: now() };
      if (patch.$incrementCallCount) {
        delete next.$incrementCallCount;
        next.callCount = (lead.callCount || 0) + 1;
      }
      leads.set(leadId, next);
      emit('modified', next);
    },

    async deleteLead(leadId) {
      leads.delete(leadId);
      activity.delete(leadId);
      for (const [appointmentId, appointment] of appointments) {
        if (appointment.leadId === leadId) appointments.delete(appointmentId);
      }
    },

    async addActivity(leadId, entry) {
      if (!activity.has(leadId)) activity.set(leadId, new Map());
      const item = { id: id(), ...entry, createdAt: now() };
      activity.get(leadId).set(item.id, item);
      return item.id;
    },

    async updateActivity(leadId, activityId, patch) {
      const items = activity.get(leadId);
      if (!items?.has(activityId)) return;
      items.set(activityId, { ...items.get(activityId), ...patch, updatedAt: now() });
    },

    async getActivity(leadId, activityId) {
      return structuredClone(activity.get(leadId)?.get(activityId) || null);
    },

    async listActivity(leadId) {
      return [...(activity.get(leadId)?.values() || [])].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map((a) => structuredClone(a));
    },

    async listProfiles() {
      return [...profiles.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map((p) => structuredClone(p));
    },
    async getProfile(profileId) {
      return profiles.has(profileId) ? structuredClone(profiles.get(profileId)) : null;
    },
    async createProfile(data) {
      const item = { id: id(), ...data, createdAt: now() };
      profiles.set(item.id, item);
      return item.id;
    },
    async updateProfile(profileId, patch) {
      if (profiles.has(profileId)) profiles.set(profileId, { ...profiles.get(profileId), ...patch, updatedAt: now() });
    },
    async deleteProfile(profileId) {
      profiles.delete(profileId);
    },
    async listAppointments({ from, to }) {
      return [...appointments.values()].filter((a) => a.start >= from && a.start <= to).sort((a, b) => a.start.localeCompare(b.start)).map((a) => structuredClone(a));
    },
    async listAppointmentsForLead(leadId) {
      return [...appointments.values()].filter((a) => a.leadId === leadId).sort((a, b) => b.start.localeCompare(a.start)).map((a) => structuredClone(a));
    },
    async getAppointment(id2) {
      return appointments.has(id2) ? structuredClone(appointments.get(id2)) : null;
    },
    async createAppointment(data) {
      const item = { id: id(), ...data, createdAt: now() };
      appointments.set(item.id, item);
      return item.id;
    },
    async updateAppointment(id2, patch) {
      if (appointments.has(id2)) appointments.set(id2, { ...appointments.get(id2), ...patch, updatedAt: now() });
    },
    async listScripts() {
      return [...scripts.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map((x) => structuredClone(x));
    },
    async getScript(scriptId) {
      return scripts.has(scriptId) ? structuredClone(scripts.get(scriptId)) : null;
    },
    async createScript(data) {
      const item = { id: id(), ...data, createdAt: now() };
      scripts.set(item.id, item);
      return item.id;
    },
    async updateScript(scriptId, patch) {
      if (scripts.has(scriptId)) scripts.set(scriptId, { ...scripts.get(scriptId), ...patch, updatedAt: now() });
    },
    async deleteScript(scriptId) {
      scripts.delete(scriptId);
    },
    async getSettings(name) {
      return structuredClone(settings.get(name) || {});
    },
    async setSettings(name, patch) {
      const next = { ...(settings.get(name) || {}), ...patch, updatedAt: now() };
      settings.set(name, next);
    },
    async upsertSms(messageId, data) {
      const previous = smsMessages.get(messageId) || {};
      const item = { ...previous, ...data, id: messageId, updatedAt: now(), createdAt: data.createdAt || previous.createdAt || now() };
      smsMessages.set(messageId, item);
      return structuredClone(item);
    },
    async getSms(messageId) {
      return structuredClone(smsMessages.get(messageId) || null);
    },
    async listSms({ leadId, limit = 300 } = {}) {
      return [...smsMessages.values()]
        .filter((item) => !leadId || item.leadId === leadId)
        .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))
        .slice(0, limit)
        .map((item) => structuredClone(item));
    },
    async publishServer(data) {
      settings.set('public:leadDesk', { ...data, updatedAt: now() });
    },
  };

  if (seed) seedDemoLeads(api);
  return api;
}

function seedDemoLeads(store) {
  const demo = [
    ['Roofing', 'Broward', '33301', 'Within 1–3 months', 'Monthly payments (financing)', true, 'Alex', 'Rivera', 'new', 12],
    ['Impact Windows & Doors', 'Miami-Dade', '33156', 'ASAP', 'Not sure yet', true, 'Jordan', 'Diaz', 'contacted', 95],
    ['Air Conditioning', 'Palm Beach', '33431', 'ASAP', 'Cash / pay in full', false, 'Sam', 'Morgan', 'new', 240],
    ['Kitchen', 'Miami-Dade', '33133', 'Within 3–6 months', 'Monthly payments (financing)', true, 'Taylor', 'Brooks', 'qualified', 1440],
    ['Bathroom', 'Broward', '33020', 'Just exploring', 'Monthly payments (financing)', true, 'Casey', 'Nguyen', 'appointment', 3100],
  ];
  demo.forEach(([projectType, county, zipCode, timeline, paymentPreference, financingInterest, firstName, lastName, status, minsAgo], i) => {
    store.createLead(
      {
        projectType,
        homeowner: 'Yes',
        county,
        zipCode,
        timeline,
        paymentPreference,
        financingInterest,
        firstName: `${firstName} (demo)`,
        lastName,
        phone: `+1305555010${i}`,
        email: `demo${i}@example.com`,
        utmSource: i % 2 ? 'google' : 'facebook',
        utmMedium: 'paid',
        utmCampaign: 'demo_campaign',
        utmContent: '',
        utmTerm: '',
        landingPage: 'http://localhost:5173/',
        status,
        source: 'demo',
        consent: { optional: [{ id: 'aiCalls', text: 'demo consent', granted: i % 2 === 0 }] },
        callCount: 0,
      },
      new Date(Date.now() - minsAgo * 60000).toISOString()
    );
  });
}
