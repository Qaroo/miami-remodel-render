import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const env = process.env;
const bool = (v) => v === '1' || v === 'true';
const list = (v) => (v || '').split(',').map((s) => s.trim()).filter(Boolean);
const argv = process.argv.slice(2);

function readServiceAccount() {
  if (env.FIREBASE_SERVICE_ACCOUNT_JSON) return JSON.parse(env.FIREBASE_SERVICE_ACCOUNT_JSON);
  if (env.FIREBASE_SERVICE_ACCOUNT_PATH) {
    const p = path.resolve(path.join(__dirname, '..'), env.FIREBASE_SERVICE_ACCOUNT_PATH);
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  }
  return null;
}

export const config = {
  port: Number(env.PORT || 8787),
  isProd: env.NODE_ENV === 'production',
  cloud: Boolean(env.K_SERVICE || env.FUNCTION_TARGET || env.RENDER),
  automationSecret: env.AUTOMATION_SECRET || '',
  mock: bool(env.MOCK_MODE),

  /**
   * Start a Cloudflare quick tunnel (`npm run live`). The tunnel URL changes on every start;
   * the server publishes it to Firestore and updates Twilio automatically.
   */
  tunnel: argv.includes('--tunnel') || bool(env.TUNNEL),

  /** Fixed public URL (only when NOT using the built-in tunnel, e.g. your own domain). */
  publicBaseUrl: (env.PUBLIC_BASE_URL || env.RENDER_EXTERNAL_URL || '').replace(/\/+$/, ''),
  /** Extra origins allowed to use the API. `*` allows any origin (auth is a bearer token, no cookies). */
  allowedOrigins: list(env.ALLOWED_ORIGINS),

  admin: {
    password: env.ADMIN_PASSWORD || '',
    sessionSecret: env.SESSION_SECRET || '',
    sessionHours: Number(env.SESSION_HOURS || 12),
  },

  firebase: {
    projectId: env.FIREBASE_PROJECT_ID || '',
    serviceAccount: null, // filled lazily below
    leadsCollection: env.LEADS_COLLECTION || 'leads',
  },

  /** Optional: Twilio settings from .env (used only when no profile is active in Lead Desk → Settings). */
  twilio: {
    accountSid: env.TWILIO_ACCOUNT_SID || '',
    authToken: env.TWILIO_AUTH_TOKEN || '',
    apiKeySid: env.TWILIO_API_KEY_SID || '',
    apiKeySecret: env.TWILIO_API_KEY_SECRET || '',
    twimlAppSid: env.TWILIO_TWIML_APP_SID || '',
    callerId: env.TWILIO_CALLER_ID || '',
    /** Skip webhook signature checks (local testing only — never in production). */
    skipSignature: bool(env.TWILIO_SKIP_SIGNATURE),
  },

  callingHours: {
    timeZone: env.CALLING_TIMEZONE || 'America/New_York',
    start: Number(env.CALLING_HOUR_START || 8),
    end: Number(env.CALLING_HOUR_END || 20),
  },

  staticDir: path.resolve(__dirname, '..', env.STATIC_DIR || '../dist'),
};

/** Twilio settings fully provided in .env (legacy fallback). */
export const envTwilio = () => {
  const t = config.twilio;
  if (!(t.accountSid && t.authToken && t.apiKeySid && t.apiKeySecret && t.twimlAppSid && t.callerId)) return null;
  return { id: 'env', name: '.env settings', mode: 'manual', ...t };
};

/** Origins allowed to call the API / open a socket. */
export function corsOrigin() {
  if (config.allowedOrigins.includes('*')) return true;
  const project = config.firebase.projectId || config.firebase.serviceAccount?.project_id || 'miamiremodel';
  const origins = new Set([
    'http://localhost:5173',
    'http://localhost:4173',
    'http://127.0.0.1:5173',
    ...(project ? [`https://${project}.web.app`, `https://${project}.firebaseapp.com`] : []),
    ...config.allowedOrigins.map((o) => o.replace(/\/+$/, '')),
  ]);
  return [...origins];
}

export function validateConfig() {
  const problems = [];
  if (!config.admin.password || config.admin.password.length < 10) problems.push('ADMIN_PASSWORD must be at least 10 characters.');
  if (!config.admin.sessionSecret || config.admin.sessionSecret.length < 32) problems.push('SESSION_SECRET must be at least 32 random characters.');
  if (!config.mock) {
    try {
      config.firebase.serviceAccount = readServiceAccount();
    } catch (e) {
      problems.push(`Could not read the Firebase service account: ${e.message}`);
    }
    if (!config.firebase.serviceAccount && !env.FIRESTORE_EMULATOR_HOST && !config.cloud) {
      problems.push('Set FIREBASE_SERVICE_ACCOUNT_PATH (or FIREBASE_SERVICE_ACCOUNT_JSON), or run with MOCK_MODE=1.');
    }
  }
  if (config.isProd && config.twilio.skipSignature) problems.push('TWILIO_SKIP_SIGNATURE cannot be used in production.');
  return problems;
}
