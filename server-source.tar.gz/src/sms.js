const rank = { accepted: 0, scheduled: 0, queued: 1, sending: 2, sent: 3, delivered: 4, read: 5, received: 4, failed: 4, undelivered: 4, canceled: 4 };
const terminal = new Set(['delivered', 'read', 'failed', 'undelivered', 'canceled']);
export function mergeSms(previous = {}, update = {}) {
  const next = { ...previous, ...update };
  if (previous.status && update.status && ((rank[update.status] ?? 0) < (rank[previous.status] ?? 0) || (terminal.has(previous.status) && !(previous.status === 'delivered' && update.status === 'read')))) {
    next.status = previous.status;
    next.errorCode = previous.errorCode || '';
    next.errorMessage = previous.errorMessage || '';
  }
  if (!next.createdAt) next.createdAt = new Date().toISOString();
  return next;
}
