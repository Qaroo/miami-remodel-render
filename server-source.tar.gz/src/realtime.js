import { Server } from 'socket.io';
import { verifySession } from './auth.js';

const ROOM = 'admins';
const SNAPSHOT_LIMIT = 500;

/**
 * Socket.IO hub.
 * Server → client events:
 *   leads:snapshot  [lead]            on connect
 *   lead:upsert     lead              new / updated lead
 *   lead:activity   { leadId, entry } note / status / call entry added or updated
 *   call:status     { leadId, activityId, status, duration, agent, at }
 *   agents          [name]            who is online
 *   ai:call, ai:transcript, ai:audio  AI phone calls (see ai/calls.js)
 *   appointment:upsert                calendar changes
 *   twilio:status   { mode, profileName, callerId }  active Twilio profile changed
 */
export function createRealtime(httpServer, { store, origin, logger = console }) {
  const io = new Server(httpServer, {
    cors: { origin },
    destroyUpgrade: false, // /ai/stream upgrades are handled separately
    pingInterval: 20000,
  });

  const online = new Map(); // socket.id -> agent

  const broadcastAgents = () => io.to(ROOM).emit('agents', [...new Set(online.values())].sort());

  io.use((socket, next) => {
    const session = verifySession(socket.handshake.auth?.token);
    if (!session) return next(new Error('unauthorized'));
    socket.data.agent = session.agent;
    next();
  });

  io.on('connection', async (socket) => {
    socket.join(ROOM);
    // Live listening to an AI call: the client joins a room per call.
    socket.on('ai:listen', (callId) => typeof callId === 'string' && socket.join(`listen:${callId.slice(0, 40)}`));
    socket.on('ai:unlisten', (callId) => typeof callId === 'string' && socket.leave(`listen:${callId.slice(0, 40)}`));
    online.set(socket.id, socket.data.agent);
    broadcastAgents();
    try {
      socket.emit('leads:snapshot', await store.listLeads(SNAPSHOT_LIMIT));
    } catch (err) {
      logger.error('[realtime] snapshot failed', err);
      socket.emit('server:error', { message: 'Could not load leads' });
    }
    socket.on('disconnect', () => {
      online.delete(socket.id);
      broadcastAgents();
    });
  });

  // One database listener for the whole server, fanned out to every admin.
  const unsubscribe = store.watchLeads(
    SNAPSHOT_LIMIT,
    ({ type, lead }) => {
      // "removed" also fires when a lead simply falls outside the newest-500 window, so it's ignored.
      if (type !== 'removed') io.to(ROOM).emit('lead:upsert', { ...lead, _event: type });
    },
    (err) => logger.error('[realtime] Firestore listener error', err)
  );

  return {
    io,
    emitActivity: (leadId, entry) => io.to(ROOM).emit('lead:activity', { leadId, entry }),
    emitLeadRemoved: (leadId) => io.to(ROOM).emit('lead:remove', { leadId }),
    /** How many agents are listening to this AI call right now. */
    listenerCount: (callId) => io.sockets.adapter.rooms.get(`listen:${callId}`)?.size || 0,
    emitAiAudio: (callId, payload) => io.to(`listen:${callId}`).emit('ai:audio', { callId, payload }),
    emitTwilioStatus: (status) => io.to(ROOM).emit('twilio:status', status),
    emitSms: (message) => io.to(ROOM).emit('sms:upsert', message),
    emitCallStatus: (payload) => io.to(ROOM).emit('call:status', { ...payload, at: new Date().toISOString() }),
    close: () => {
      unsubscribe?.();
      io.close();
    },
  };
}
