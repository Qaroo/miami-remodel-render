/**
 * Call bookkeeping shared by the Twilio webhooks and the mock dialer.
 * Every call is an `activity` entry on the lead ({ type: 'call', status, duration, agent }).
 */

// Twilio CallStatus → our status vocabulary
export const normalizeStatus = (s) =>
  ({
    queued: 'initiated',
    initiated: 'initiated',
    ringing: 'ringing',
    'in-progress': 'answered',
    answered: 'answered',
    completed: 'completed',
    busy: 'busy',
    'no-answer': 'no-answer',
    failed: 'failed',
    canceled: 'canceled',
  })[s] || s;

const FINAL = new Set(['completed', 'busy', 'no-answer', 'failed', 'canceled']);
export const isFinal = (status) => FINAL.has(status);

export function createCallService({ store, realtime }) {
  async function startCall({ leadId, agent, callSid = '', to }) {
    const activityId = await store.addActivity(leadId, {
      type: 'call',
      direction: 'outbound',
      status: 'initiated',
      agent,
      to,
      callSid,
      duration: 0,
    });
    await store.updateLead(leadId, {
      lastCallAt: new Date().toISOString(),
      lastCallStatus: 'initiated',
      lastCallBy: agent,
      $incrementCallCount: true,
    });
    const entry = await store.getActivity(leadId, activityId);
    realtime.emitActivity(leadId, entry);
    realtime.emitCallStatus({ leadId, activityId, status: 'initiated', duration: 0, agent });
    return activityId;
  }

  async function updateCall({ leadId, activityId, status: rawStatus, duration, childCallSid }) {
    const current = await store.getActivity(leadId, activityId);
    if (!current) return null;
    const status = normalizeStatus(rawStatus);

    // Never move a finished call back to an earlier state (webhooks can arrive out of order).
    if (isFinal(current.status)) return current;
    // A call that was answered and then ends is "completed", even if Twilio later reports "canceled".
    const finalStatus = current.status === 'answered' && isFinal(status) && status !== 'completed' ? 'completed' : status;

    const patch = { status: finalStatus };
    if (duration !== undefined && duration !== null && !Number.isNaN(Number(duration))) patch.duration = Number(duration);
    if (childCallSid) patch.childCallSid = childCallSid;
    if (finalStatus === 'answered') patch.answeredAt = new Date().toISOString();
    if (isFinal(finalStatus)) patch.endedAt = new Date().toISOString();

    await store.updateActivity(leadId, activityId, patch);

    const leadPatch = { lastCallStatus: finalStatus };
    if (finalStatus === 'answered') {
      const lead = await store.getLead(leadId);
      if (lead?.status === 'new') leadPatch.status = 'contacted';
    }
    await store.updateLead(leadId, leadPatch);

    const entry = await store.getActivity(leadId, activityId);
    realtime.emitActivity(leadId, entry);
    realtime.emitCallStatus({ leadId, activityId, status: finalStatus, duration: entry.duration || 0, agent: entry.agent });
    return entry;
  }

  return { startCall, updateCall };
}
