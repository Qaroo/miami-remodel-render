import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';

const URL_RE = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/i;

/** Find a cloudflared binary: CLOUDFLARED_BIN → one on your PATH → the npm package (downloaded on first use). */
async function resolveBinary(logger) {
  if (process.env.CLOUDFLARED_BIN) return process.env.CLOUDFLARED_BIN;
  const which = spawnSync(process.platform === 'win32' ? 'where' : 'which', ['cloudflared'], { encoding: 'utf8' });
  const onPath = which.status === 0 && which.stdout.split(/\r?\n/)[0].trim();
  if (onPath) return onPath;

  const pkg = await import('cloudflared');
  const bin = pkg.bin || pkg.default?.bin;
  if (!fs.existsSync(bin)) {
    logger.log('  Downloading cloudflared (one time)…');
    await (pkg.install || pkg.default.install)(bin);
  }
  return bin;
}

/**
 * Start a Cloudflare quick tunnel to the local server and keep it running.
 * Calls onUrl(url) every time a (new) public URL is ready. Restarts cloudflared if it exits.
 */
export async function startTunnel({ port, onUrl, logger = console }) {
  const bin = await resolveBinary(logger);
  let child = null;
  let stopped = false;
  let restarts = 0;
  let restartTimer = null;

  const start = () => {
    let announced = false;
    child = spawn(bin, ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${port}`], {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    const scan = (chunk) => {
      const text = chunk.toString();
      if (process.env.TUNNEL_DEBUG) process.stderr.write(text);
      const match = !announced && text.match(URL_RE);
      if (match) {
        announced = true;
        restarts = 0;
        onUrl(match[0]);
      }
    };
    child.stdout.on('data', scan);
    child.stderr.on('data', scan);

    child.on('error', (err) => logger.error(`[tunnel] could not start cloudflared: ${err.message}`));
    child.on('exit', (code) => {
      if (stopped) return;
      restarts += 1;
      const wait = Math.min(30000, 2000 * restarts);
      logger.error(`[tunnel] cloudflared exited (code ${code}). Restarting in ${Math.round(wait / 1000)}s…`);
      restartTimer = setTimeout(start, wait);
    });
  };

  start();
  process.once('exit', () => child?.kill());

  return {
    stop() {
      stopped = true;
      clearTimeout(restartTimer);
      child?.kill();
    },
  };
}
