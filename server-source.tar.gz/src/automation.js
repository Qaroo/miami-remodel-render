import crypto from 'node:crypto';
import { Router } from 'express';
import { config } from './config.js';
import { callingWindow } from './leads.js';

export function automationRoutes({ store, aiCalls }) {
  const r = Router();
  r.post('/internal/auto-call', async (req, res) => {
    const expected = config.automationSecret;
    const supplied = req.get('authorization')?.replace(/^Bearer /, '') || '';
    const hash = (v) => crypto.createHash('sha256').update(v).digest();
    if (!expected || !crypto.timingSafeEqual(hash(expected), hash(supplied))) return res.status(401).json({ error: 'unauthorized' });
    const id = String(req.body?.leadId || '');
    if (!/^[\w-]{1,128}$/.test(id)) return res.status(400).json({ error: 'invalid leadId' });
    const ref = store.db.collection('autoCallJobs').doc(id);
    const existing = await ref.get();
    if (existing.exists && ['started', 'starting', 'review', 'skipped'].includes(existing.data().status)) return res.json({ status: existing.data().status });
    const lead = await store.getLead(id);
    if (!lead || lead.doNotCall || !/^\+1\d{10}$/.test(lead.phone || '')) {
      await ref.set({ status: 'skipped', reason: 'Lead missing, opted out, or invalid phone' }, { merge: true });
      return res.json({ status: 'skipped' });
    }
    if (!callingWindow(config.callingHours).allowed) {
      await store.db.runTransaction(async (tx) => {
        const d = await tx.get(ref);
        if (!d.exists || d.data().status === 'waiting') tx.set(ref, { status: 'waiting', reason: 'Outside calling hours' }, { merge: true });
      });
      return res.json({ status: 'waiting' });
    }
    const claimed = await store.db.runTransaction(async (tx) => {
      const d = await tx.get(ref);
      if (d.exists && ['started', 'starting', 'review', 'skipped'].includes(d.data().status)) return false;
      tx.set(ref, { status: 'starting', startedAt: new Date().toISOString() }, { merge: true });
      return true;
    });
    if (!claimed) return res.json({ status: 'already-claimed' });
    try {
      const result = await aiCalls.start({ leadId: id, agent: 'Webhook automation' });
      await ref.set({ status: 'started', ...result }, { merge: true });
      res.json({ status: 'started', ...result });
    } catch (err) {
      // Never repeat an uncertain phone request automatically: it may already have reached Twilio.
      const status = err.safeToRetry ? 'waiting' : 'review';
      await ref.set({ status, error: err.message, failedAt: new Date().toISOString() }, { merge: true });
      await store.updateLead(id, { autoCallError: err.message });
      res.json({ status, error: err.message });
    }
  });
  return r;
}
