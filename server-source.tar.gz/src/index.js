import fs from 'node:fs';
import { automationRoutes } from './automation.js';
import http from 'node:http';
import path from 'node:path';
import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import { config, corsOrigin, validateConfig } from './config.js';
import { createCallService } from './calls.js';
import { createRealtime } from './realtime.js';
import { adminRoutes } from './routes/admin.js';
import { mockDialerRoutes } from './routes/mockDialer.js';
import { twilioRoutes } from './routes/twilio.js';
import { twilioSettingsRoutes } from './routes/twilioSettings.js';
import { aiRoutes } from './routes/ai.js';
import { calendarRoutes } from './routes/calendar.js';
import { createCalendar } from './calendar.js';
import { createAiCalls } from './ai/calls.js';
import { createAiSettings } from './ai/settings.js';
import { runtime } from './runtime.js';
import { createTwilioProfiles } from './twilio/profiles.js';

const problems = validateConfig();
if (problems.length) {
  console.error('\n✖ Server configuration problems:\n' + problems.map((p) => `  • ${p}`).join('\n') + '\n\nSee server/.env.example\n');
  process.exit(1);
}

const store = config.mock
  ? (await import('./store/memoryStore.js')).createMemoryStore()
  : (await import('./store/firestoreStore.js')).createFirestoreStore();

const app = express();
app.set('trust proxy', 1); // behind Cloudflare Tunnel / a reverse proxy
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));

const origin = corsOrigin();
const server = http.createServer(app);
const realtime = createRealtime(server, { store, origin });
const calls = createCallService({ store, realtime });
const profiles = createTwilioProfiles({ store });
profiles.onChange((status) => realtime.emitTwilioStatus(status));
const aiSettings = createAiSettings({ store });
const calendar = createCalendar({ store, realtime });
const aiCalls = createAiCalls({ store, realtime, profiles, aiSettings, calendar });

// Twilio Media Streams for AI calls: wss://<public>/ai/stream
server.on('upgrade', (req, socket, head) => {
  if (req.url?.split('?')[0] === '/ai/stream') aiCalls.handleUpgrade(req, socket, head);
});

// ── API ───────────────────────────────────────────────
const api = express.Router();
api.use(cors({ origin, maxAge: 600 }));
api.use(express.json({ limit: '100kb' }));
api.get('/health', (req, res) =>
  res.json({ ok: true, app: 'miami-remodel-lead-desk', store: store.kind, twilio: profiles.status().mode, publicUrl: runtime.publicUrl })
);
api.use(automationRoutes({ store, aiCalls }));
api.use(adminRoutes({ store, realtime, profiles }));
api.use(twilioSettingsRoutes({ profiles }));
api.use(aiRoutes({ store, aiSettings, aiCalls }));
api.use(calendarRoutes({ calendar }));

const twilio = twilioRoutes({ store, calls, profiles, aiCalls, realtime });
api.use(twilio.api);
api.use(mockDialerRoutes({ store, calls, profiles }));
api.use((req, res) => res.status(404).json({ error: 'not found' }));

app.use('/api', api);
app.use('/twilio', twilio.hooks);

// ── Optional: serve the built site + admin panel (npm run build in the project root) ──
if (fs.existsSync(path.join(config.staticDir, 'index.html'))) {
  app.use(express.static(config.staticDir, { index: false, maxAge: '1h' }));
  app.use((req, res, next) => {
    if (req.method !== 'GET' || req.path.startsWith('/socket.io')) return next();
    res.sendFile(path.join(config.staticDir, 'index.html'));
  });
}

app.use((err, req, res, next) => {
  console.error('[server] unhandled error', err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'server error' });
});

// ── Publish the public URL so miamiremodel.web.app/admin can find this server ──
async function publish(url, online = true) {
  try {
    await store.publishServer({ url, online, startedAt: startedAt.toISOString() });
    return true;
  } catch (err) {
    console.error(`  ✖ Could not publish the server address to Firestore: ${err.message}`);
    return false;
  }
}

const startedAt = new Date();
let tunnel = null;

runtime.onPublicUrl(async (url) => {
  console.log(`\n🌐 Public URL: ${url}`);
  if (await publish(url)) console.log('  ✔ Lead Desk address updated — open the admin panel from your website /admin');
  await profiles.syncVoiceUrl();
});

await profiles.init().catch((err) => console.error(`  ✖ Could not load Twilio profiles: ${err.message}`));

server.listen(config.port, async () => {
  const t = profiles.status();
  console.log(`\n✔ Miami Remodel Lead Desk server on http://localhost:${config.port}`);
  console.log(`  store: ${store.kind}   twilio: ${t.mode === 'live' ? `live (${t.profileName})` : t.mode}`);

  if (config.tunnel) {
    console.log('  Starting Cloudflare Tunnel…');
    try {
      const { startTunnel } = await import('./tunnel.js');
      tunnel = await startTunnel({ port: config.port, onUrl: (url) => runtime.setPublicUrl(url) });
    } catch (err) {
      console.error(`  ✖ Could not start the tunnel: ${err.message}`);
    }
  } else if (runtime.publicUrl) {
    console.log(`  public URL: ${runtime.publicUrl}`);
    await publish(runtime.publicUrl);
    await profiles.syncVoiceUrl();
  } else {
    console.log('  No public URL. Run `npm run live` to open a tunnel for the admin panel and Twilio.');
  }
  console.log('');
});

let shuttingDown = false;
const shutdown = async () => {
  if (shuttingDown) return process.exit(0);
  shuttingDown = true;
  console.log('\nStopping…');
  tunnel?.stop();
  aiCalls.close();
  await Promise.race([publish(runtime.publicUrl, false), new Promise((r) => setTimeout(r, 2500))]);
  realtime.close();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
